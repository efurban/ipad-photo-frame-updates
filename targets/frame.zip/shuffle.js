/* Persistent shuffle rounds; ES5 for iOS 12. */
(function(root){
  'use strict';
  function Queue(saved, random) {
    saved=saved || {};this.random=random || Math.random;
    this.pending=Array.isArray(saved.pending)?saved.pending.slice():[];
    this.seen=Array.isArray(saved.seen)?saved.seen.slice():[];
    this.last=Array.isArray(saved.last)?saved.last.slice():[];
    this.limit=Number(saved.limit)||3;
  }
  Queue.prototype.mix=function(items){
    var a=items.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(this.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;
  };
  Queue.prototype.order=function(all,current){
    var self=this; current=current || [];
    this.seen=this.seen.filter(function(x){return all.indexOf(x)>=0;});
    this.pending=this.pending.filter(function(x,i,a){return all.indexOf(x)>=0 && self.seen.indexOf(x)<0 && a.indexOf(x)===i;});
    var added=all.filter(function(x){return self.seen.indexOf(x)<0 && self.pending.indexOf(x)<0;});
    this.mix(added).forEach(function(x){var at=Math.floor(self.random()*(self.pending.length+1));self.pending.splice(at,0,x);});
    if(!this.pending.length && !current.length && all.length){
      this.seen=[];
      var fresh=this.mix(all.filter(function(x){return self.last.indexOf(x)<0;}));
      this.pending=fresh.concat(this.mix(all.filter(function(x){return self.last.indexOf(x)>=0;})));
      this.limit=fresh.length ? Math.min(3,fresh.length) : Math.min(3,all.length);
    }
    return current.filter(function(x){return all.indexOf(x)>=0;}).concat(this.pending.filter(function(x){return current.indexOf(x)<0;}));
  };
  Queue.prototype.shown=function(urls){
    var self=this;urls.forEach(function(x){if(self.seen.indexOf(x)<0)self.seen.push(x);});
    this.pending=this.pending.filter(function(x){return urls.indexOf(x)<0;});this.last=urls.slice();this.limit=3;
  };
  Queue.prototype.state=function(){return {pending:this.pending,seen:this.seen,last:this.last,limit:this.limit};};
  root.FrameShuffle={Queue:Queue};
})(typeof window==='undefined'?module.exports:window);
