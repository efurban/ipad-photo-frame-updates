/* Persistent shuffle rounds; ES5 for iOS 12. */
(function(root){
  'use strict';
  function unique(items){
    var seen=Object.create(null);
    return items.filter(function(x){if(seen[x])return false;seen[x]=true;return true;});
  }
  function Queue(saved, random) {
    saved=saved || {};this.random=random || Math.random;
    this.pending=Array.isArray(saved.pending)?unique(saved.pending):[];
    this.seen=Array.isArray(saved.seen)?unique(saved.seen):[];
    this.last=Array.isArray(saved.last)?unique(saved.last):[];
    this.groups=Array.isArray(saved.groups)?saved.groups.filter(Array.isArray).map(function(g){return unique(g).slice(0,3);}).filter(function(g){return g.length>1;}):[];
    this.limit=Number(saved.limit)||3;
  }
  Queue.prototype.mix=function(items){
    var a=items.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(this.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;
  };
  Queue.prototype.regroup=function(fresh,tail){
    // Keep last round's screen companions apart in the next random queue.
    // At most three adjacent items can share a screen, so only look back two.
    var avoid=Object.create(null),result=[],self=this;
    this.groups.forEach(function(group){
      group.forEach(function(a){
        if(!avoid[a])avoid[a]=Object.create(null);
        group.forEach(function(b){if(a!==b)avoid[a][b]=true;});
      });
    });
    function append(items,count){
      var remaining=self.mix(items);
      var added=0;
      while(remaining.length && added<count){
        var best=0,bestCost=3;
        for(var i=0;i<remaining.length;i++){
          var cost=0,partners=avoid[remaining[i]];
          for(var j=Math.max(0,result.length-2);partners && j<result.length;j++){
            if(partners[result[j]])cost++;
          }
          if(cost<bestCost){best=i;bestCost=cost;}
          if(!cost)break;
        }
        result.push(remaining.splice(best,1)[0]);
        added++;
      }
      return remaining;
    }
    // Protect only the first screen, then mix the former last screen back in.
    // Appending it at the end would lock that same pair/trio together forever.
    var rest=append(fresh,Math.min(3,fresh.length)).concat(tail);
    append(rest,rest.length);
    return result;
  };
  Queue.prototype.order=function(all,current){
    var self=this; all=unique(all);current=unique(current || []);
    this.seen=this.seen.filter(function(x){return all.indexOf(x)>=0;});
    this.groups=this.groups.map(function(group){return group.filter(function(x){return all.indexOf(x)>=0;});}).filter(function(group){return group.length>1;});
    this.pending=this.pending.filter(function(x,i,a){return all.indexOf(x)>=0 && self.seen.indexOf(x)<0 && a.indexOf(x)===i;});
    var added=all.filter(function(x){return self.seen.indexOf(x)<0 && self.pending.indexOf(x)<0;});
    this.mix(added).forEach(function(x){var at=Math.floor(self.random()*(self.pending.length+1));self.pending.splice(at,0,x);});
    if(!this.pending.length && !current.length && all.length){
      this.seen=[];
      var fresh=all.filter(function(x){return self.last.indexOf(x)<0;});
      this.pending=this.regroup(fresh,all.filter(function(x){return self.last.indexOf(x)>=0;}));
      this.groups=[];
      this.limit=fresh.length ? Math.min(3,fresh.length) : Math.min(3,all.length);
    }
    return current.filter(function(x){return all.indexOf(x)>=0;}).concat(this.pending.filter(function(x){return current.indexOf(x)<0;}));
  };
  Queue.prototype.shown=function(urls){
    var self=this;urls=unique(urls);
    // Manual back navigation must not grow the pairing history.
    if(urls.length>1 && urls.some(function(x){return self.seen.indexOf(x)<0;}))this.groups.push(urls.slice(0,3));
    urls.forEach(function(x){if(self.seen.indexOf(x)<0)self.seen.push(x);});
    this.pending=this.pending.filter(function(x){return urls.indexOf(x)<0;});this.last=urls.slice();this.limit=3;
  };
  Queue.prototype.state=function(){return {pending:this.pending,seen:this.seen,last:this.last,groups:this.groups,limit:this.limit};};
  root.FrameShuffle={Queue:Queue,unique:unique};
})(typeof window==='undefined'?module.exports:window);
