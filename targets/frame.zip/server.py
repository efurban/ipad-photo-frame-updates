#!/usr/bin/env python3
"""Local-only photo frame and anonymous public iCloud album cache. Python 3.9+."""
import argparse
import hashlib
import json
import uuid
import logging
from logging.handlers import RotatingFileHandler
import os
import re
from pathlib import Path
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger('photoframe')
BUILD = 'frame-ota-7'
NIGHT_DEFAULT = {'enabled': False, 'start': '22:00', 'end': '07:00', 'display': 'black'}


def validate_night(value):
    if not isinstance(value, dict) or type(value.get('enabled')) is not bool:
        raise ValueError('Choose whether the night schedule is enabled')
    result = {'enabled': value['enabled']}
    for key in ('start', 'end'):
        val = value.get(key)
        if not isinstance(val, str) or not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]', val):
            raise ValueError('Enter valid bedtime and wake times')
        result[key] = val
    display = value.get('display', 'black')
    if display not in ('black', 'clock'):
        raise ValueError('Choose a valid night display')
    result['display'] = display
    if result['start'] == result['end']:
        raise ValueError('Bedtime and wake time must be different')
    return result


def night_active(settings, local):
    minute = local.tm_hour * 60 + local.tm_min
    start, end = [int(settings[k][:2]) * 60 + int(settings[k][3:]) for k in ('start', 'end')]
    return settings['enabled'] and (start <= minute < end if start < end else minute >= start or minute < end)


def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    os.replace(temp, path)


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def unique_manifest(items):
    """Different album records can refer to the same cached media file."""
    result, seen = [], set()
    for item in items:
        if item['file'] not in seen:
            seen.add(item['file'])
            result.append(item)
    return result


class Album:
    def __init__(self, config):
        self.config = config
        self.data = Path(config.get('data_dir', ROOT / 'data'))
        self.frame_base = Path(config.get('frame_base', ROOT))
        self.photos = self.data / 'photos'
        self.photos.mkdir(parents=True, exist_ok=True)
        self.manifest_path = self.data / 'manifest.json'
        self.status_path = self.data / 'status.json'
        self.manifest = unique_manifest(read_json(self.manifest_path, []))
        self.status = read_json(self.status_path, {})
        self.status.update(syncing=False, next_sync=None, count=len(self.manifest),
                           videos=sum(p.get('kind') == 'video' for p in self.manifest))
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.running = True
        self.client = {}
        self.auto_update_path = self.data / 'auto-update-settings.json'
        self.auto_update = read_json(self.auto_update_path, {})
        if not isinstance(self.auto_update, dict):
            self.auto_update = {}
        self.auto_wake = threading.Event()
        self.auto_ready_at = 0
        self.faces_path=self.data / 'faces.json'
        self.faces=read_json(self.faces_path,{})
        self.face_working=False
        self.night_path = self.data / 'night-settings.json'
        try:
            self.night = validate_night(read_json(self.night_path, NIGHT_DEFAULT))
        except ValueError:
            self.night = dict(NIGHT_DEFAULT)
        # Procursus supplies its maintained CA bundle; certificate checks stay enabled.
        ca = Path('/etc/ssl/certs/ca-certificates.crt')
        self.ssl = ssl.create_default_context(cafile=str(ca) if ca.exists() else None)

    def display_state(self):
        now = time.time()
        local = time.localtime(now)
        with self.lock:
            settings = dict(self.night)
        return {'night': settings, 'active': night_active(settings, local),
                'local_time': time.strftime('%H:%M', local),
                'timezone': time.strftime('%Z', local), 'build': BUILD}

    def update_state(self):
        result = read_json(self.frame_base / 'updates' / 'status.json', {'phase': 'disabled'})
        if not isinstance(result, dict):
            result = {'phase': 'failed'}
        with self.lock:
            result['auto_install'] = self.auto_update.get('enabled') is True
        result.pop('release_notes', None)
        phase = result.get('phase')
        expected = (BUILD if phase == 'current' else result.get('available')
                    if phase in ('available', 'downloading', 'waiting', 'starting') else None)
        if not expected:
            return result
        # The existing TUF updater writes this verified cache after a successful
        # refresh. Bind notes to its reported build/sequence, never a remote URL.
        custom = read_json(self.frame_base / 'updates' / 'metadata' / 'targets.json', {})
        for key in ('signed', 'targets', 'frame.zip', 'custom'):
            custom = custom.get(key, {}) if isinstance(custom, dict) else {}
        if (not isinstance(custom, dict) or custom.get('build') != expected
                or type(custom.get('sequence')) is not int or custom['sequence'] < 1
                or (result.get('sequence') is not None and result['sequence'] != custom['sequence'])):
            return result
        notes = custom.get('release_notes')
        if not isinstance(notes, dict):
            return result
        localized = {'build': expected}
        for language in ('en', 'zh'):
            lines = notes.get(language)
            if (isinstance(lines, list) and 1 <= len(lines) <= 3
                    and all(isinstance(line, str) and 1 <= len(line.strip()) <= 160 for line in lines)):
                localized[language] = [line.strip() for line in lines]
        if len(localized) > 1:
            result['release_notes'] = localized
        return result

    def set_auto_update(self, enabled):
        if type(enabled) is not bool:
            raise ValueError('Choose whether automatic updates are enabled')
        with self.lock:
            value = dict(self.auto_update, enabled=enabled)
            if not enabled:
                # Cancel only our unconsumed requests, never a manual install.
                for path in (self.frame_base / 'updates' / 'commands').glob('auto-install-*.json'):
                    try:
                        path.unlink()
                        value.pop('attempted_build', None)
                        value.pop('attempted_at', None)
                    except FileNotFoundError:
                        pass
            atomic_json(self.auto_update_path, value)
            self.auto_update = value
        self.auto_wake.set()

    def auto_update_step(self, now=None):
        now = time.time() if now is None else now
        with self.lock:
            if self.auto_update.get('enabled') is not True:
                return
            if not read_json(self.frame_base / 'updater' / 'config.json', {}).get('enabled'):
                return
            state = read_json(self.frame_base / 'updates' / 'status.json', {})
            if not isinstance(state, dict):
                return
            build = state.get('available')
            if not isinstance(build, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}', build):
                return
            action = None
            if state.get('phase') == 'available' and build != BUILD:
                attempted = self.auto_update.get('attempted_at', 0)
                if (self.auto_update.get('attempted_build') == build
                        and isinstance(attempted, (int, float)) and now - attempted < 21600):
                    return
                action = 'install'
            elif state.get('phase') == 'waiting':
                # A live slideshow acknowledges at a media boundary. With no
                # recent browser, the server can acknowledge without interrupting it.
                seen = self.client.get('seen', 0)
                if isinstance(seen, (int, float)) and now - seen >= 60 and now - self.auto_ready_at >= 10:
                    action = 'ready'
            if not action:
                return
            folder = self.frame_base / 'updates' / 'commands'
            folder.mkdir(parents=True, exist_ok=True)
            if len(list(folder.glob('*.json'))) >= 10:
                return
            if action == 'install':
                if list(folder.glob('auto-install-*.json')):
                    return
                value = dict(self.auto_update, attempted_build=build, attempted_at=now)
                atomic_json(self.auto_update_path, value)
                self.auto_update = value
            else:
                self.auto_ready_at = now
            atomic_json(folder / ('auto-' + action + '-' + uuid.uuid4().hex + '.json'),
                        {'action': action, 'build': build})

    def auto_update_loop(self):
        while self.running:
            try:
                self.auto_update_step()
            except (OSError, ValueError, TypeError):
                LOG.exception('Automatic update deferred; current app preserved')
            self.auto_wake.wait(15)
            self.auto_wake.clear()

    def face_state(self, names=None):
        with self.lock:
            files=[p['file'] for p in self.manifest if p['file'].endswith(('.jpg','.png'))]
            selected=files if names is None else [n for n in names if n in files]
            ready={n:self.faces[n].get('faces',[]) for n in selected if n in self.faces and not self.faces[n].get('error')}
            return {'items':ready,'processed':sum(n in self.faces and not self.faces[n].get('error') for n in files),
                    'total':len(files),'working':self.face_working,
                    'errors':sum(bool(self.faces.get(n,{}).get('error')) for n in files)}

    def face_loop(self):
        while self.running:
            with self.lock:
                files=[p['file'] for p in self.manifest if p['file'].endswith(('.jpg','.png'))]
            for name in files:
                if not self.running:break
                with self.lock:
                    previous=self.faces.get(name)
                    if previous and (not previous.get('error') or time.time()-previous.get('attempt',0)<21600):continue
                    self.face_working=True
                try:
                    result=subprocess.run([sys.executable,'-I',str(ROOT/'native_faces.py'),str(self.photos/name)],
                                          capture_output=True,text=True,timeout=30)
                    if result.returncode:raise RuntimeError('Native face worker unavailable')
                    data=json.loads(result.stdout)
                    faces=data['faces']
                    if not isinstance(faces,list) or len(faces)>50:raise ValueError('Invalid face result')
                    for face in faces:
                        if not all(isinstance(face.get(k),(int,float)) and 0<=face[k]<=1 for k in ('x','y','w','h')):raise ValueError('Invalid face box')
                        if face['x']+face['w']>1.00001 or face['y']+face['h']>1.00001:raise ValueError('Invalid face bounds')
                    entry={'faces':faces,'attempt':time.time()}
                except (OSError,ValueError,KeyError,RuntimeError,subprocess.TimeoutExpired):
                    entry={'faces':[],'error':True,'attempt':time.time()}
                with self.lock:
                    self.faces[name]=entry
                    # Prune metadata for files no longer in the cache.
                    self.faces={n:v for n,v in self.faces.items() if (self.photos/n).is_file()}
                    atomic_json(self.faces_path,self.faces)
                    self.face_working=False
                # Background work is bounded to one small image at a time.
                for _ in range(10):
                    if not self.running:break
                    time.sleep(.2)
            for _ in range(30):
                if not self.running:break
                time.sleep(1)

    def request(self, url, body=None):
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname or ''
        if parsed.scheme != 'https' or not any(host.endswith('.' + d) or host == d for d in
                                               ('icloud.com', 'icloud-content.com', 'icloud.com.cn', 'icloud-content.com.cn')):
            raise ValueError('Unexpected album download host')
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers={
            'Content-Type': 'text/plain', 'User-Agent': 'iPadPhotoFrame/1.0',
            'Origin': 'https://photos.icloud.com'})
        return urllib.request.urlopen(req, timeout=45, context=self.ssl)

    def api(self, url, body):
        for attempt in range(3):
            try:
                with self.request(url, body) as response:
                    result = json.load(response)
                if 'serverErrorCode' in result:
                    raise RuntimeError('Album API: ' + str(result['serverErrorCode']))
                return result
            except (OSError, ValueError, RuntimeError):
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)

    def records(self):
        key = self.config['album_url'].rstrip('/').split('/')[-1]
        params = {'sharing_url_key': key, 'remapEnums': 'true', 'getCurrentSyncToken': 'true'}
        base = '/database/1/com.apple.photos.cloud/production/'
        url = 'https://ckdatabasews.icloud.com' + base + 'public/records/resolve?'
        result = self.api(url + urllib.parse.urlencode(params), {'shortGUIDs': [{'value': key}]})
        resolved = result.get('results', [{}])[0]
        if resolved.get('requireAppleLogin') or not resolved.get('anonymousPublicAccess'):
            raise RuntimeError('This album does not allow anonymous public viewing')
        access = resolved['anonymousPublicAccess']
        zone = resolved['zoneID']
        params['publicAccessAuthToken'] = access['token']
        endpoint = access['databasePartition'].rstrip('/') + base + 'shared/records/query?'
        endpoint += urllib.parse.urlencode(params)
        count_result = self.api(endpoint, {'zoneID': zone, 'query': {
            'recordType': 'HyperionIndexCountLookup', 'filterBy': [{
                'fieldName': 'indexCountID', 'comparator': 'IN',
                'fieldValue': {'value': ['CPLAssetByAddedDate'], 'type': 'STRING_LIST'}}]}})
        count = int(count_result['records'][0]['fields']['itemCount']['value'])
        if count > 20000:
            raise RuntimeError('Album exceeds the 20,000 item limit')
        masters, assets = {}, []
        offset = 0
        while offset < count:
            payload = {'zoneID': zone, 'resultsLimit': min(200, (count - offset) * 2), 'query': {
                'recordType': 'CPLAssetAndMasterByAddedDate', 'filterBy': [
                    {'fieldName': 'direction', 'comparator': 'EQUALS',
                     'fieldValue': {'value': 'ASCENDING', 'type': 'STRING'}},
                    {'fieldName': 'startRank', 'comparator': 'EQUALS',
                     'fieldValue': {'value': offset, 'type': 'INT64'}}]}}
            page = self.api(endpoint, payload).get('records', [])
            page_assets = [r for r in page if r['recordType'] == 'CPLAsset' and not r.get('deleted')]
            for r in page:
                if r['recordType'] == 'CPLMaster' and not r.get('deleted'):
                    masters[r['recordName']] = r
            if not page_assets:
                raise RuntimeError('Incomplete album listing; keeping the previous cache')
            assets.extend(page_assets)
            offset += len(page_assets)
        fields = resolved['share'].get('fields', {})
        title = fields.get('cloudkit.title', {}).get('value', 'Photo Frame')
        return title, assets, masters

    @staticmethod
    def resource(master):
        f = master['fields']
        media_type = f.get('itemType', {}).get('value', '')
        video = f.get('dataClassType', {}).get('value') == 2 or media_type in (
            'public.movie', 'public.video', 'public.mpeg-4', 'com.apple.quicktime-movie',
            'public.avi', 'public.mpeg')
        if video:
            # Prefer Apple's smaller web rendition over the camera original.
            for name in ('resVidMed', 'resVidSmall', 'resVidFull', 'resVideoMed', 'resOriginal'):
                item = f.get(name + 'Res', {}).get('value')
                if item:
                    uti = f.get(name + 'FileType', {}).get('value', 'public.mpeg-4')
                    return item, '.mov' if uti == 'com.apple.quicktime-movie' else '.mp4', 'video', uti
            return None, None, 'video', None
        for name in ('resJPEGFull', 'resJPEGMed', 'resOriginal', 'resJPEGThumb'):
            item = f.get(name + 'Res', {}).get('value')
            uti = f.get(name + 'FileType', {}).get('value', '')
            if item and (uti in ('public.jpeg', 'public.png') or name.startswith('resJPEG')):
                uti = 'public.png' if uti == 'public.png' else 'public.jpeg'
                return item, '.png' if uti == 'public.png' else '.jpg', 'photo', uti
        return None, None, 'photo', None

    def sync(self):
        with self.lock:
            self.status.update(syncing=True, last_attempt=time.time(), error=None)
        try:
            title, assets, masters = self.records()
            manifest = []
            downloaded = 0
            skipped = 0
            cache_size = sum(p.stat().st_size for p in self.photos.iterdir() if p.is_file())
            for asset in assets:
                f = asset['fields']
                master = masters.get(f.get('masterRef', {}).get('value', {}).get('recordName'))
                if master is None:
                    raise RuntimeError('Missing photo metadata; keeping previous cache')
                resource, ext, kind, uti = self.resource(master)
                if not resource:
                    skipped += 1
                    continue
                limit = (200 if kind == 'video' else 40) * 1024 * 1024
                if resource.get('size', 0) > limit:
                    skipped += 1
                    continue
                checksum = resource['fileChecksum']
                filename = hashlib.sha256(checksum.encode()).hexdigest() + ext
                target = self.photos / filename
                if not target.exists():
                    url = resource['downloadURL'].replace('${f}', uti)
                    part = self.photos / (filename + '.part')
                    try:
                        with self.request(url) as response, part.open('wb') as out:
                            total = 0
                            while True:
                                block = response.read(65536)
                                if not block:
                                    break
                                total += len(block)
                                if total > limit:
                                    raise RuntimeError('Media exceeds the per-file cache limit')
                                out.write(block)
                        with part.open('rb') as check:
                            signature = check.read(8)
                        valid_image = signature.startswith(b'\xff\xd8\xff') or signature == b'\x89PNG\r\n\x1a\n'
                        valid_video = signature[4:8] in (b'ftyp', b'moov', b'wide', b'mdat')
                        if not (valid_video if kind == 'video' else valid_image):
                            raise RuntimeError('Download was not a supported image/video container')
                        os.replace(part, target)
                    finally:
                        if part.exists():
                            part.unlink()
                    downloaded += 1
                    cache_size += target.stat().st_size
                manifest.append({'id': asset['recordName'], 'file': filename, 'kind': kind})
                if cache_size > self.config.get('max_cache_bytes', 2 * 1024 ** 3):
                    raise RuntimeError('Photo cache is full; keeping previous slideshow')
            # Publish only a complete sync. A network failure never destroys cached photos.
            manifest = unique_manifest(manifest)
            atomic_json(self.manifest_path, manifest)
            with self.lock:
                self.manifest = manifest
                self.status.update(title=title, count=len(manifest), skipped=skipped,
                                   last_success=time.time(), downloaded=downloaded, error=None,
                                   videos=sum(p.get('kind') == 'video' for p in manifest))
            keep = {p['file'] for p in manifest}
            # Retain removed files for a day so an already-visible slide still loads.
            for p in self.photos.iterdir():
                if p.name not in keep and p.is_file() and time.time() - p.stat().st_mtime > 86400:
                    p.unlink()
            LOG.info('Album synced: %s photos, %s new, %s skipped', len(manifest), downloaded, skipped)
        except Exception as error:
            # Do not log signed download URLs / public-access bearer tokens.
            message = str(error) if isinstance(error, RuntimeError) else type(error).__name__
            with self.lock:
                self.status['error'] = message
            LOG.warning('Sync failed (%s); retaining cached photos', message)
        finally:
            with self.lock:
                self.status.update(syncing=False, next_sync=time.time() + self.config.get('sync_seconds', 300))
                atomic_json(self.status_path, self.status)

    def loop(self):
        while self.running:
            self.sync()
            self.wake.wait(self.config.get('sync_seconds', 300))
            self.wake.clear()


def handler(album):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, status, body, content_type):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/health':
                return self.send(200, json.dumps({'build': BUILD, 'ready': True}).encode(), 'application/json')
            if path == '/api/update':
                return self.send(200, json.dumps(album.update_state()).encode(), 'application/json')
            if path == '/api/faces':
                query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                names=query.get('files',[''])[0].split(',')[:6]
                names=[n for n in names if re.fullmatch(r'[0-9a-f]{64}\.(jpg|png)',n)]
                return self.send(200,json.dumps(album.face_state(names)).encode(),'application/json')
            if path == '/api/display':
                return self.send(200, json.dumps(album.display_state()).encode(), 'application/json')
            if path == '/api/photos':
                with album.lock:
                    result = ['/photos/' + p['file'] for p in album.manifest
                              if (album.photos / p['file']).is_file()]
                return self.send(200, json.dumps(result).encode(), 'application/json')
            if path == '/api/status':
                with album.lock:
                    result = dict(album.status)
                    result['client'] = dict(album.client)
                    result['video'] = dict(getattr(album, 'last_video', {}))
                return self.send(200, json.dumps(result, ensure_ascii=False).encode(), 'application/json; charset=utf-8')
            if path in ('/layout.js', '/shuffle.js'):
                return self.send(200, (ROOT / path[1:]).read_bytes(), 'application/javascript; charset=utf-8')
            if path in ('/', '/index.html'):
                return self.send(200, (ROOT / 'index.html').read_bytes(), 'text/html; charset=utf-8')
            if path.startswith('/photos/'):
                name = path[len('/photos/'):]
                if not re.fullmatch(r'[0-9a-f]{64}\.(jpg|png|mp4|mov)', name):
                    return self.send(404, b'Not found', 'text/plain')
                photo = album.photos / name
                if photo.is_file():
                    size = photo.stat().st_size
                    mime = {'.jpg': 'image/jpeg', '.png': 'image/png',
                            '.mp4': 'video/mp4', '.mov': 'video/quicktime'}[photo.suffix]
                    start, end = 0, size - 1
                    requested = self.headers.get('Range')
                    if requested:
                        match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested.strip())
                        try:
                            if not match or not any(match.groups()):
                                raise ValueError()
                            if match[1]:
                                start = int(match[1])
                                if match[2]:
                                    end = min(end, int(match[2]))
                            else:
                                length = int(match[2])
                                if length <= 0:
                                    raise ValueError()
                                start = max(0, size - length)
                            if start > end or start >= size:
                                raise ValueError()
                        except ValueError:
                            self.send_response(416)
                            self.send_header('Content-Range', 'bytes */' + str(size))
                            self.send_header('Content-Length', '0')
                            self.end_headers()
                            return
                    self.send_response(206 if requested else 200)
                    self.send_header('Content-Type', mime)
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Content-Length', str(end - start + 1))
                    self.send_header('Cache-Control', 'private, max-age=86400')
                    if requested:
                        self.send_header('Content-Range', 'bytes %s-%s/%s' % (start, end, size))
                    self.end_headers()
                    try:
                        with photo.open('rb') as source:
                            source.seek(start)
                            remaining = end - start + 1
                            while remaining > 0:
                                block = source.read(min(65536, remaining))
                                if not block:
                                    break
                                self.wfile.write(block)
                                remaining -= len(block)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
            return self.send(404, b'Not found', 'text/plain')

        def do_POST(self):
            origin = self.headers.get('Origin')
            if origin and urllib.parse.urlsplit(origin).hostname not in ('127.0.0.1', 'localhost', '::1'):
                return self.send(403, b'Forbidden', 'text/plain')
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/update':
                try:
                    if self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json':
                        raise ValueError('JSON required')
                    size = int(self.headers.get('Content-Length', 0))
                    if not 1 <= size <= 256:
                        raise ValueError('Invalid action size')
                    command = json.loads(self.rfile.read(size))
                    action = command.get('action')
                    if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'):
                        return self.send(403, b'Forbidden', 'text/plain')
                    build = command.get('build')
                    if action == 'ready' and (not isinstance(build, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}', build)):
                        raise ValueError('Invalid update build')
                    if action not in ('check', 'install', 'ready', 'auto'):
                        raise ValueError('Invalid action')
                    settings = read_json(album.frame_base / 'updater' / 'config.json', {})
                    if not settings.get('enabled'):
                        return self.send(409, b'{"error":"disabled"}', 'application/json')
                    if action == 'auto':
                        album.set_auto_update(command.get('enabled'))
                        return self.send(200, json.dumps(album.update_state()).encode(), 'application/json')
                    folder = album.frame_base / 'updates' / 'commands'
                    folder.mkdir(parents=True, exist_ok=True)
                    if len(list(folder.glob('*.json'))) >= 10:
                        return self.send(429, b'{"error":"busy"}', 'application/json')
                    atomic_json(folder / (uuid.uuid4().hex + '.json'), {'action': action, 'build': build})
                    return self.send(200, b'{"queued":true}', 'application/json')
                except (ValueError, TypeError, AttributeError):
                    return self.send(400, b'{"error":"invalid_action"}', 'application/json')
                except OSError:
                    LOG.exception('Update settings or command could not be saved')
                    return self.send(503, b'{"error":"save_failed"}', 'application/json')
            if path == '/api/display':
                try:
                    size = int(self.headers.get('Content-Length', 0))
                    if not 1 <= size <= 2048:
                        raise ValueError('Invalid settings size')
                    value = validate_night(json.loads(self.rfile.read(size)))
                    with album.lock:
                        atomic_json(album.night_path, value)
                        album.night = value
                    return self.send(200, json.dumps(album.display_state()).encode(), 'application/json')
                except (ValueError, TypeError) as error:
                    return self.send(400, json.dumps({'error': str(error)}).encode(), 'application/json')
            if path == '/api/sync':
                album.wake.set()
                return self.send(200, b'{"queued":true}', 'application/json')
            if path == '/api/client':
                try:
                    size = int(self.headers.get('Content-Length', 0))
                    if size < 1 or size > 2048:
                        raise ValueError('Invalid report size')
                    data = json.loads(self.rfile.read(size))
                    with album.lock:
                        album.client = {k: data.get(k) for k in
                                        ('loaded', 'width', 'height', 'standalone', 'userAgent', 'kind', 'event', 'currentTime', 'duration', 'build', 'night', 'nightClock', 'language', 'recoveries', 'hidden', 'photoCount', 'viewport', 'shuffle', 'remaining', 'seenCount', 'videoBackdrop', 'faceAware', 'facesApplied')}
                        album.client['seen'] = time.time()
                        if data.get('kind') == 'video':
                            album.last_video = dict(album.client)
                    return self.send(200, b'{"ok":true}', 'application/json')
                except (ValueError, TypeError):
                    return self.send(400, b'Invalid report', 'text/plain')
            return self.send(404, b'Not found', 'text/plain')
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(ROOT / 'config.json'))
    parser.add_argument('--sync-once', action='store_true')
    args = parser.parse_args()
    config = read_json(Path(args.config), {})
    parent = os.environ.get('FRAME_SUPERVISOR_PID')
    if parent:
        # Do not leave an orphan occupying the port if the supervisor is killed.
        def watch_parent():
            while os.getppid() == int(parent):
                time.sleep(1)
            os._exit(0)
        threading.Thread(target=watch_parent, daemon=True).start()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    album = Album(config)
    logfile = RotatingFileHandler(str(album.data / 'photoframe.log'), maxBytes=1048576, backupCount=2)
    logfile.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    LOG.addHandler(logfile)
    if args.sync_once:
        album.sync()
        raise SystemExit(1 if album.status.get('error') else 0)
    threading.Thread(target=album.loop, daemon=True).start()
    threading.Thread(target=album.face_loop, daemon=True).start()
    threading.Thread(target=album.auto_update_loop, daemon=True).start()
    server = ThreadingHTTPServer(('127.0.0.1', config.get('port', 8080)), handler(album))
    LOG.info('Photo Frame ready on http://127.0.0.1:%s', server.server_port)
    server.serve_forever()


if __name__ == '__main__':
    main()
