#!/usr/bin/env python3
"""Local-only photo frame and anonymous public iCloud album cache. Python 3.9+."""
import argparse
import base64
import hmac
import hashlib
import json
import uuid
import logging
from logging.handlers import RotatingFileHandler
import os
import re
from pathlib import Path
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger('photoframe')
BUILD = 'frame-ota-11'
REPORT_DEFAULT = {'salt': 'rodjKwt7Oewxsk4_pl9Q6g==', 'token': 'gAAAAABq2nmdhtjn_itDfty8EMPv29TWF2DFcSpczjKL-9GYy5CO21kBKM-fBGzIdNEVtQj5da3mS4zMIjqCSvLwKQGXs313p_PAuyIef7UOkXHDrW2tIn1oPF_5M_7LRvwLk2XBvpH9kb1eeUyHxgm9J2kgobiDSQ=='}
NIGHT_DEFAULT = {'enabled': False, 'start': '22:00', 'end': '07:00', 'display': 'black'}


def validate_night(value):
    if not isinstance(value, dict) or type(value.get('enabled')) is not bool:
        raise ValueError('Choose whether the night schedule is enabled')
    result = {'enabled': value['enabled']}
    for key in ('start', 'end'):
        val = value.get(key)
        if not isinstance(val, str) or not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]', val):
            raise ValueError('Enter valid bedtime and wake times')
        result[key] = val
    display = value.get('display', 'black')
    if display not in ('black', 'clock'):
        raise ValueError('Choose a valid night display')
    result['display'] = display
    if result['start'] == result['end']:
        raise ValueError('Bedtime and wake time must be different')
    return result


def night_active(settings, local):
    minute = local.tm_hour * 60 + local.tm_min
    start, end = [int(settings[k][:2]) * 60 + int(settings[k][3:]) for k in ('start', 'end')]
    return settings['enabled'] and (start <= minute < end if start < end else minute >= start or minute < end)


def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    os.replace(temp, path)


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def unique_manifest(items):
    """Different album records can refer to the same cached media file."""
    result, seen = [], set()
    for item in items:
        if item['file'] not in seen:
            seen.add(item['file'])
            result.append(item)
    return result


class DiagnosticLog(RotatingFileHandler):
    def handleError(self, record):
        # A full disk must not turn diagnostics into a playback failure.
        self.failed = True


class Diagnostics:
    """Opt-in 24-hour recorder; no media, URLs or credentials in its reports."""
    WINDOW = 86400
    PUBLIC = ('run', 'started', 'ends', 'checkpoint', 'status', 'pages', 'photos', 'videos',
              'media_errors', 'recoveries', 'sync_ok', 'sync_failed', 'server_starts',
              'browser_sessions', 'observed', 'night', 'hidden', 'settings', 'unobserved',
              'max_gap', 'last_client', 'last_page', 'builds', 'recent', 'possible_repeats',
              'short_pages', 'repeat_window_limited')

    def __init__(self, data, clock=time.time):
        self.clock, self.lock, self.failure = clock, threading.RLock(), False
        self.folder = Path(data) / 'diagnostics'
        self.path = self.folder / 'monitor.json'
        self.value, self.handler = {}, None
        try:
            self.folder.mkdir(exist_ok=True)
            saved = read_json(self.path, {})
            required = {'status', 'ends', 'cursor', 'last_client', 'server_starts', 'checkpoint', 'started', 'recent'}
            if (isinstance(saved, dict) and saved.get('version') == 1 and required.issubset(saved)
                    and saved['status'] in ('recording','complete') and isinstance(saved['recent'],list)
                    and all(type(saved.get(key)) in (int,float) and 0 <= saved[key] < 1e12
                            for key in ('started','ends','cursor','checkpoint','last_client','server_starts'))
                    and saved['ends'] >= saved['started']):
                self.value = saved
            elif saved:
                self.failure = True
            self.handler = DiagnosticLog(str(self.folder / 'events.jsonl'),
                                         maxBytes=1048576, backupCount=7, encoding='utf-8', delay=True)
            self.handler.setFormatter(logging.Formatter('%(message)s'))
            self.handler.failed = False
            with self.lock:
                if self._active():
                    self._accrue(self.clock())
                    if self.value['status'] == 'recording':
                        self.value['server_starts'] += 1
                        self._event('server-start', important=True)
                    self._save(True)
        except (OSError, ValueError, TypeError, KeyError):
            self.failure = True
            self.value = {}

    def close(self):
        if self.handler:
            self.handler.close()

    def _active(self):
        return self.value.get('status') == 'recording'

    def _event(self, event, important=False, **fields):
        entry = dict(at=round(self.clock(), 3), run=self.value.get('run'), event=event, **fields)
        if important:
            self.value['recent'] = (self.value.get('recent', []) + [entry])[-20:]
        if self.handler:
            record = logging.LogRecord('frame-diagnostics', logging.INFO, '', 0,
                                       json.dumps(entry, separators=(',', ':')), (), None)
            self.handler.handle(record)
            if self.handler.failed:
                self.failure = True

    def _save(self, force=False):
        now = self.clock()
        if not self.value or (not force and now - self.value.get('checkpoint', 0) < 60):
            return
        try:
            self.value['checkpoint'] = now
            atomic_json(self.path, self.value)
        except OSError:
            self.failure = True

    def _accrue(self, now):
        if not self._active():
            return
        value = self.value
        end = min(now, value['ends'])
        cursor = value['cursor']
        if end <= cursor:
            return
        # Heartbeat coverage is evidence of reporting, not proof of rendering.
        observed = max(0, min(end, value['last_client'] + 45) - cursor) if value['last_client'] else 0
        value['observed'] += observed
        value['unobserved'] += end - cursor - observed
        mode = value.get('mode')
        if mode in ('night', 'hidden', 'settings'):
            value[mode] += observed
        value['cursor'] = end
        if now >= value['ends']:
            value['status'] = 'complete'
            self._event('complete', important=True)
            self._save(True)

    def start(self):
        with self.lock:
            self._accrue(self.clock())
            if self._active():
                if self.failure:
                    self.failure = False
                    self.handler.failed = False
                    self._save(True)
                    if self.failure:
                        raise OSError('Diagnostic recording could not be saved')
                return self.snapshot()
            if not self.handler:
                raise OSError('Diagnostic storage unavailable')
            now = self.clock()
            self.value = dict(version=1, run=uuid.uuid4().hex[:12], salt=uuid.uuid4().hex,
                              started=now, ends=now + self.WINDOW, cursor=now, checkpoint=0,
                              status='recording', pages=0, photos=0, videos=0, media_errors=0,
                              recoveries=0, sync_ok=0, sync_failed=0, server_starts=1,
                              browser_sessions=0, observed=0, night=0, hidden=0, settings=0,
                              unobserved=0, max_gap=0, last_client=0, last_page=0,
                              builds=[], recent=[], session='', page_key='', sampled=0,
                              possible_repeats=0, short_pages=0, repeat_window_limited=False,
                              queue_seen={}, queue_count=0, interrupted=True, previous_kind='', previous_interval=8)
            self.failure = False
            self.handler.failed = False
            self._event('started', important=True, build=BUILD)
            self._save(True)
            if self.failure:
                raise OSError('Diagnostic recording could not be saved')
            return self.snapshot()

    @staticmethod
    def _number(value, maximum=1000000):
        return round(float(value), 3) if type(value) in (int, float) and 0 <= value <= maximum else None

    def record(self, report):
        # Best effort: malformed or unwritable diagnostics never stop playback.
        try:
            with self.lock:
                now = self.clock()
                self._accrue(now)
                if not self._active():
                    return
                value = self.value
                details = report.get('diagnostics')
                details = details if isinstance(details, dict) else {}
                event = report.get('event', '')
                allowed = ('loaded', 'playing', 'ended', 'error', 'heartbeat', 'progress',
                           'night-start', 'night-end', 'hidden', 'visible', 'settings-open', 'settings-close')
                recovery = isinstance(event, str) and event.startswith('recovery: ')
                event = 'recovery' if recovery else event if event in allowed else 'heartbeat'
                if value['last_client']:
                    value['max_gap'] = max(value['max_gap'], now - value['last_client'])
                value['last_client'] = now
                value['mode'] = ('hidden' if report.get('hidden') is True else 'night' if report.get('night') is True
                                 else 'settings' if details.get('settings') is True else 'playback')
                if value['mode'] != 'playback' or recovery:
                    value['interrupted'] = True
                session = details.get('session', '')
                if isinstance(session, str) and re.fullmatch(r'[a-z0-9-]{1,60}', session):
                    if session != value['session']:
                        value['session'] = session
                        value['queue_seen'] = {}
                        value['queue_count'] = 0
                        value['interrupted'] = True
                        value['browser_sessions'] += 1
                        self._event('browser-session', important=True)
                build = report.get('build')
                if isinstance(build, str) and re.fullmatch(r'[a-zA-Z0-9._-]{1,80}', build) and build not in value['builds']:
                    value['builds'] = (value['builds'] + [build])[-8:]
                fields = {'mode': value['mode']}
                for source, dest in ((report, 'seenCount'), (report, 'remaining'), (report, 'photoCount'),
                                     (details, 'page'), (details, 'age'), (details, 'previous_dwell'),
                                     (details, 'interval'), (report, 'currentTime')):
                    number = self._number(source.get(dest))
                    if number is not None:
                        fields[dest] = number
                media = details.get('media', [])
                fields['media'] = [hashlib.sha256((value['salt'] + name).encode()).hexdigest()[:12]
                                   for name in media[:3] if isinstance(name, str) and re.fullmatch(r'[a-f0-9]{64}\.(jpg|png|mp4|mov)', name)] if isinstance(media, list) else []
                if event in ('loaded', 'playing'):
                    key = '%s:%s' % (value['session'], fields.get('page'))
                    if key != value['page_key']:
                        count = fields.get('seenCount', 0)
                        if count < value['queue_count']:
                            value['queue_seen'] = {}
                        repeated = any(name in value['queue_seen'] for name in fields['media'])
                        if report.get('shuffle') is True and repeated and not details.get('manual'):
                            value['possible_repeats'] += 1
                            self._event('possible-repeat', important=True, **fields)
                        dwell = fields.get('previous_dwell')
                        if (dwell is not None and dwell < value['previous_interval'] * .7
                                and value['previous_kind'] == 'loaded' and not value['interrupted']
                                and not details.get('manual')):
                            value['short_pages'] += 1
                            self._event('short-page', important=True, dwell=dwell)
                        for name in fields['media']:
                            if len(value['queue_seen']) < 4096:
                                value['queue_seen'][name] = True
                            else:
                                value['repeat_window_limited'] = True
                        value['queue_count'] = count
                        value['previous_kind'] = event
                        value['previous_interval'] = fields.get('interval', 8)
                        value['interrupted'] = False
                        value['page_key'] = key
                        value['pages'] += 1
                        value['last_page'] = now
                        if event == 'playing':
                            value['videos'] += 1
                        else:
                            value['photos'] += max(1, min(3, int(fields.get('photoCount', 1))))
                elif event == 'error':
                    value['media_errors'] += 1
                elif event == 'recovery':
                    value['recoveries'] += 1
                sampled = event in ('heartbeat', 'progress')
                if not sampled or now - value['sampled'] >= 60:
                    self._event(event, important=not sampled and event not in ('loaded', 'playing', 'ended'), **fields)
                    if sampled:
                        value['sampled'] = now
                self._save(event in ('error', 'recovery'))
        except (OSError, ValueError, TypeError, KeyError, OverflowError):
            self.failure = True

    def sync(self, success, count=0, downloaded=0):
        try:
            with self.lock:
                self._accrue(self.clock())
                if not self._active():
                    return
                self.value['sync_ok' if success else 'sync_failed'] += 1
                self._event('sync-ok' if success else 'sync-failed', important=not success,
                            count=int(count), downloaded=int(downloaded))
                self._save(not success)
        except (OSError, ValueError, TypeError, KeyError):
            self.failure = True

    def snapshot(self):
        with self.lock:
            self._accrue(self.clock())
            self._save()
            result = {key: self.value[key] for key in self.PUBLIC if key in self.value}
            result.setdefault('status', 'not-started')
            result['storage_error'] = self.failure
            result['log_limit_bytes'] = 8 * 1048576
            result['raw_logs_may_rotate'] = True
            if self.value:
                result['elapsed'] = max(0, min(self.clock(), self.value['ends']) - self.value['started'])
            return result


class ReportDelivery:
    """Opt-in, write-only Healthchecks log delivery; credentials stay local."""
    def __init__(self, data, diagnostics, context, clock=time.time):
        self.folder, self.diagnostics, self.context, self.clock = Path(data), diagnostics, context, clock
        self.path, self.state_path = self.folder/'report-settings.json', self.folder/'report-delivery.json'
        self.lock, self.wake = threading.RLock(), threading.Event()
        self.config = read_json(self.path, {})
        self.state = read_json(self.state_path, {})
        if not isinstance(self.config, dict):self.config = {}
        if not isinstance(self.state, dict):self.state = {}
        try:
            if self.config.get('endpoint'):self.config['endpoint'] = self.endpoint(self.config['endpoint'])
        except ValueError:
            self.config = {}

    def apply_default(self, album_url, frame_base):
        """Unseal this family's default once; explicit saved preferences win."""
        if self.config.get('endpoint') or not REPORT_DEFAULT:
            return False
        try:
            token = album_url.rstrip('/').split('/')[-1]
            if not isinstance(token,str) or not 20 <= len(token) <= 200:
                return False
            blob = REPORT_DEFAULT
            salt = base64.b64decode(blob['salt'], altchars=b'-_', validate=True)
            sealed = blob['token']
            if len(salt) != 16 or not isinstance(sealed,str) or len(sealed) > 4096:
                return False
            raw = base64.b64decode(sealed, altchars=b'-_', validate=True)
            if len(raw) < 73 or raw[0] != 0x80 or (len(raw)-57) % 16:
                return False
            key = hashlib.pbkdf2_hmac('sha256',token.encode(),salt,120000,32)
            # Fernet: authenticate version/timestamp/IV/ciphertext before decryption.
            if not hmac.compare_digest(hmac.new(key[:16],raw[:-32],hashlib.sha256).digest(),raw[-32:]):
                return False
            settings = read_json(Path(frame_base)/'updater/config.json',{})
            openssl = settings.get('openssl','/usr/bin/openssl')
            if openssl == '/usr/bin/openssl' and not Path(openssl).is_file():
                openssl = str(Path(frame_base)/'updater/bin/openssl')
            result = subprocess.run([openssl,'enc','-d','-aes-128-cbc','-K',key[16:].hex(),'-iv',raw[9:25].hex()],
                                    input=raw[25:-32],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5)
            if result.returncode or len(result.stdout)>256:
                return False
            address = self.endpoint(result.stdout.decode('utf-8'))
            enabled = self.config.get('enabled') is True if self.path.exists() else True
            self.save(enabled,address)
            return True
        except (OSError,ValueError,TypeError,KeyError,AttributeError,subprocess.SubprocessError):
            # Wrong album, damaged defaults or unavailable crypto must not stop playback.
            return False

    @staticmethod
    def endpoint(value):
        if not isinstance(value, str) or len(value) > 256:
            raise ValueError('Use a private Healthchecks ping address')
        parsed = urllib.parse.urlsplit(value.strip())
        match = re.fullmatch(r'/([0-9a-fA-F-]{36})(?:/log)?/?', parsed.path)
        if (parsed.scheme != 'https' or parsed.netloc != 'hc-ping.com' or not match
                or parsed.query or parsed.fragment):
            raise ValueError('Use an HTTPS hc-ping.com address')
        try: identifier = str(uuid.UUID(match.group(1)))
        except ValueError: raise ValueError('Invalid private ping address') from None
        return 'https://hc-ping.com/' + identifier + '/log'

    def save(self, enabled, endpoint=''):
        if type(enabled) is not bool:
            raise ValueError('Choose whether remote reports are enabled')
        with self.lock:
            previous = self.config.get('endpoint', '')
            address = self.endpoint(endpoint) if endpoint else previous
            if enabled and not address:
                raise ValueError('Add the private ping address first')
            value = {'enabled':enabled, 'endpoint':address}
            temporary = self.folder/('.report-' + uuid.uuid4().hex + '.tmp')
            try:
                descriptor = os.open(str(temporary), os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600)
                with os.fdopen(descriptor, 'w') as stream:
                    json.dump(value,stream);stream.flush();os.fsync(stream.fileno())
                os.replace(str(temporary),str(self.path))
            finally:
                if temporary.exists():temporary.unlink()
            self.config = value
            if address != previous:
                self.state = {}
                atomic_json(self.state_path,self.state)
        self.wake.set()

    def status(self):
        with self.lock:
            return dict(enabled=self.config.get('enabled') is True, configured=bool(self.config.get('endpoint')),
                        service='Healthchecks.io',last_success=self.state.get('last_success'),
                        last_error=self.state.get('last_error'),next_attempt=self.state.get('next_attempt'))

    def upload(self, address, payload):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, message, headers, newurl):return None
        opener = urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=self.context))
        request = urllib.request.Request(address, data=json.dumps(payload,separators=(',',':')).encode(),
                                         headers={'Content-Type':'text/plain; charset=utf-8','User-Agent':'PhotoFrame-Health/1'})
        with opener.open(request,timeout=10) as response:
            if response.status != 200 or response.read(64).strip() != b'OK':
                raise OSError('Report was not accepted')

    def step(self, test=False):
        report = self.diagnostics.snapshot()
        now = self.clock()
        with self.lock:
            config = dict(self.config)
            if not config.get('enabled') or not config.get('endpoint'):
                if test:raise ValueError('Configure and enable remote reports first')
                return
            if not test:
                if not report.get('started'):return
                same_run = self.state.get('last_run') == report.get('run')
                if same_run and self.state.get('last_status') == 'complete':return
                if now < self.state.get('next_attempt',0):return
                if (same_run and report['status'] != 'complete'
                        and now-self.state.get('last_success',0) < 900):return
        payload = dict(report, schema=1)
        # Only aggregate counts and event names/times go to the hosted service.
        payload['recent'] = [{key:event[key] for key in ('at','event') if key in event}
                             for event in report.get('recent',[])]
        if test:payload = {'schema':1,'status':'setup-test','build':BUILD,'at':now}
        error = None
        try:self.upload(config['endpoint'],payload)
        except Exception:error = 'upload-failed'  # Never log a URL-bearing exception.
        with self.lock:
            if self.config != config:return
            if error:
                attempts = min(5,self.state.get('attempts',0)+1)
                self.state.update(last_error=error,attempts=attempts,next_attempt=now+min(900,60*2**(attempts-1)))
            else:
                self.state.update(last_success=now,last_error=None,attempts=0,next_attempt=0)
                if not test:self.state.update(last_run=report['run'],last_status=report['status'])
            try:atomic_json(self.state_path,self.state)
            except OSError:self.state['last_error'] = 'storage-failed'
        if test and error:raise OSError('Private report upload failed')


class Album:
    def __init__(self, config):
        self.config = config
        self.data = Path(config.get('data_dir', ROOT / 'data'))
        self.frame_base = Path(config.get('frame_base', ROOT))
        self.photos = self.data / 'photos'
        self.photos.mkdir(parents=True, exist_ok=True)
        self.diagnostics = Diagnostics(self.data)
        self.manifest_path = self.data / 'manifest.json'
        self.status_path = self.data / 'status.json'
        self.manifest = unique_manifest(read_json(self.manifest_path, []))
        self.status = read_json(self.status_path, {})
        self.status.update(syncing=False, next_sync=None, count=len(self.manifest),
                           videos=sum(p.get('kind') == 'video' for p in self.manifest))
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.running = True
        self.client = {}
        self.auto_update_path = self.data / 'auto-update-settings.json'
        self.auto_update = read_json(self.auto_update_path, {})
        if not isinstance(self.auto_update, dict):
            self.auto_update = {}
        self.auto_wake = threading.Event()
        self.auto_ready_at = 0
        self.faces_path=self.data / 'faces.json'
        self.faces=read_json(self.faces_path,{})
        self.face_working=False
        self.night_path = self.data / 'night-settings.json'
        try:
            self.night = validate_night(read_json(self.night_path, NIGHT_DEFAULT))
        except ValueError:
            self.night = dict(NIGHT_DEFAULT)
        # Procursus supplies its maintained CA bundle; certificate checks stay enabled.
        ca = Path('/etc/ssl/certs/ca-certificates.crt')
        self.ssl = ssl.create_default_context(cafile=str(ca) if ca.exists() else None)
        self.reports = ReportDelivery(self.data, self.diagnostics, self.ssl)
        self.reports.apply_default(config.get('album_url',''),self.frame_base)

    def diagnostic_state(self):
        return dict(self.diagnostics.snapshot(), remote=self.reports.status())

    def report_loop(self):
        while self.running:
            try:self.reports.step()
            except Exception:pass  # Diagnostics and networking must not stop playback.
            self.reports.wake.wait(30)
            self.reports.wake.clear()

    def display_state(self):
        now = time.time()
        local = time.localtime(now)
        with self.lock:
            settings = dict(self.night)
        return {'night': settings, 'active': night_active(settings, local),
                'local_time': time.strftime('%H:%M', local),
                'timezone': time.strftime('%Z', local), 'build': BUILD}

    def update_state(self):
        result = read_json(self.frame_base / 'updates' / 'status.json', {'phase': 'disabled'})
        if not isinstance(result, dict):
            result = {'phase': 'failed'}
        with self.lock:
            result['auto_install'] = self.auto_update.get('enabled') is True
        result.pop('release_notes', None)
        phase = result.get('phase')
        expected = (BUILD if phase == 'current' else result.get('available')
                    if phase in ('available', 'downloading', 'waiting', 'starting') else None)
        if not expected:
            return result
        # The existing TUF updater writes this verified cache after a successful
        # refresh. Bind notes to its reported build/sequence, never a remote URL.
        custom = read_json(self.frame_base / 'updates' / 'metadata' / 'targets.json', {})
        for key in ('signed', 'targets', 'frame.zip', 'custom'):
            custom = custom.get(key, {}) if isinstance(custom, dict) else {}
        if (not isinstance(custom, dict) or custom.get('build') != expected
                or type(custom.get('sequence')) is not int or custom['sequence'] < 1
                or (result.get('sequence') is not None and result['sequence'] != custom['sequence'])):
            return result
        notes = custom.get('release_notes')
        if not isinstance(notes, dict):
            return result
        localized = {'build': expected}
        for language in ('en', 'zh'):
            lines = notes.get(language)
            if (isinstance(lines, list) and 1 <= len(lines) <= 3
                    and all(isinstance(line, str) and 1 <= len(line.strip()) <= 160 for line in lines)):
                localized[language] = [line.strip() for line in lines]
        if len(localized) > 1:
            result['release_notes'] = localized
        return result

    def set_auto_update(self, enabled):
        if type(enabled) is not bool:
            raise ValueError('Choose whether automatic updates are enabled')
        with self.lock:
            value = dict(self.auto_update, enabled=enabled)
            if not enabled:
                # Cancel only our unconsumed requests, never a manual install.
                for path in (self.frame_base / 'updates' / 'commands').glob('auto-install-*.json'):
                    try:
                        path.unlink()
                        value.pop('attempted_build', None)
                        value.pop('attempted_at', None)
                    except FileNotFoundError:
                        pass
            atomic_json(self.auto_update_path, value)
            self.auto_update = value
        self.auto_wake.set()

    def auto_update_step(self, now=None):
        now = time.time() if now is None else now
        with self.lock:
            if self.auto_update.get('enabled') is not True:
                return
            if not read_json(self.frame_base / 'updater' / 'config.json', {}).get('enabled'):
                return
            state = read_json(self.frame_base / 'updates' / 'status.json', {})
            if not isinstance(state, dict):
                return
            build = state.get('available')
            if not isinstance(build, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}', build):
                return
            action = None
            if state.get('phase') == 'available' and build != BUILD:
                attempted = self.auto_update.get('attempted_at', 0)
                if (self.auto_update.get('attempted_build') == build
                        and isinstance(attempted, (int, float)) and now - attempted < 21600):
                    return
                action = 'install'
            elif state.get('phase') == 'waiting':
                # A live slideshow acknowledges at a media boundary. With no
                # recent browser, the server can acknowledge without interrupting it.
                seen = self.client.get('seen', 0)
                if isinstance(seen, (int, float)) and now - seen >= 60 and now - self.auto_ready_at >= 10:
                    action = 'ready'
            if not action:
                return
            folder = self.frame_base / 'updates' / 'commands'
            folder.mkdir(parents=True, exist_ok=True)
            if len(list(folder.glob('*.json'))) >= 10:
                return
            if action == 'install':
                if list(folder.glob('auto-install-*.json')):
                    return
                value = dict(self.auto_update, attempted_build=build, attempted_at=now)
                atomic_json(self.auto_update_path, value)
                self.auto_update = value
            else:
                self.auto_ready_at = now
            atomic_json(folder / ('auto-' + action + '-' + uuid.uuid4().hex + '.json'),
                        {'action': action, 'build': build})

    def auto_update_loop(self):
        while self.running:
            try:
                self.auto_update_step()
            except (OSError, ValueError, TypeError):
                LOG.exception('Automatic update deferred; current app preserved')
            self.auto_wake.wait(15)
            self.auto_wake.clear()

    def face_state(self, names=None):
        with self.lock:
            files=[p['file'] for p in self.manifest if p['file'].endswith(('.jpg','.png'))]
            selected=files if names is None else [n for n in names if n in files]
            ready={n:self.faces[n].get('faces',[]) for n in selected if n in self.faces and not self.faces[n].get('error')}
            return {'items':ready,'processed':sum(n in self.faces and not self.faces[n].get('error') for n in files),
                    'total':len(files),'working':self.face_working,
                    'errors':sum(bool(self.faces.get(n,{}).get('error')) for n in files)}

    def face_loop(self):
        while self.running:
            with self.lock:
                files=[p['file'] for p in self.manifest if p['file'].endswith(('.jpg','.png'))]
            for name in files:
                if not self.running:break
                with self.lock:
                    previous=self.faces.get(name)
                    if previous and (not previous.get('error') or time.time()-previous.get('attempt',0)<21600):continue
                    self.face_working=True
                try:
                    result=subprocess.run([sys.executable,'-I',str(ROOT/'native_faces.py'),str(self.photos/name)],
                                          capture_output=True,text=True,timeout=30)
                    if result.returncode:raise RuntimeError('Native face worker unavailable')
                    data=json.loads(result.stdout)
                    faces=data['faces']
                    if not isinstance(faces,list) or len(faces)>50:raise ValueError('Invalid face result')
                    for face in faces:
                        if not all(isinstance(face.get(k),(int,float)) and 0<=face[k]<=1 for k in ('x','y','w','h')):raise ValueError('Invalid face box')
                        if face['x']+face['w']>1.00001 or face['y']+face['h']>1.00001:raise ValueError('Invalid face bounds')
                    entry={'faces':faces,'attempt':time.time()}
                except (OSError,ValueError,KeyError,RuntimeError,subprocess.TimeoutExpired):
                    entry={'faces':[],'error':True,'attempt':time.time()}
                with self.lock:
                    self.faces[name]=entry
                    # Prune metadata for files no longer in the cache.
                    self.faces={n:v for n,v in self.faces.items() if (self.photos/n).is_file()}
                    atomic_json(self.faces_path,self.faces)
                    self.face_working=False
                # Background work is bounded to one small image at a time.
                for _ in range(10):
                    if not self.running:break
                    time.sleep(.2)
            for _ in range(30):
                if not self.running:break
                time.sleep(1)

    def request(self, url, body=None):
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname or ''
        if parsed.scheme != 'https' or not any(host.endswith('.' + d) or host == d for d in
                                               ('icloud.com', 'icloud-content.com', 'icloud.com.cn', 'icloud-content.com.cn')):
            raise ValueError('Unexpected album download host')
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers={
            'Content-Type': 'text/plain', 'User-Agent': 'iPadPhotoFrame/1.0',
            'Origin': 'https://photos.icloud.com'})
        return urllib.request.urlopen(req, timeout=45, context=self.ssl)

    def api(self, url, body):
        for attempt in range(3):
            try:
                with self.request(url, body) as response:
                    result = json.load(response)
                if 'serverErrorCode' in result:
                    raise RuntimeError('Album API: ' + str(result['serverErrorCode']))
                return result
            except (OSError, ValueError, RuntimeError):
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)

    def records(self):
        key = self.config['album_url'].rstrip('/').split('/')[-1]
        params = {'sharing_url_key': key, 'remapEnums': 'true', 'getCurrentSyncToken': 'true'}
        base = '/database/1/com.apple.photos.cloud/production/'
        url = 'https://ckdatabasews.icloud.com' + base + 'public/records/resolve?'
        result = self.api(url + urllib.parse.urlencode(params), {'shortGUIDs': [{'value': key}]})
        resolved = result.get('results', [{}])[0]
        if resolved.get('requireAppleLogin') or not resolved.get('anonymousPublicAccess'):
            raise RuntimeError('This album does not allow anonymous public viewing')
        access = resolved['anonymousPublicAccess']
        zone = resolved['zoneID']
        params['publicAccessAuthToken'] = access['token']
        endpoint = access['databasePartition'].rstrip('/') + base + 'shared/records/query?'
        endpoint += urllib.parse.urlencode(params)
        count_result = self.api(endpoint, {'zoneID': zone, 'query': {
            'recordType': 'HyperionIndexCountLookup', 'filterBy': [{
                'fieldName': 'indexCountID', 'comparator': 'IN',
                'fieldValue': {'value': ['CPLAssetByAddedDate'], 'type': 'STRING_LIST'}}]}})
        count = int(count_result['records'][0]['fields']['itemCount']['value'])
        if count > 20000:
            raise RuntimeError('Album exceeds the 20,000 item limit')
        masters, assets = {}, []
        offset = 0
        while offset < count:
            payload = {'zoneID': zone, 'resultsLimit': min(200, (count - offset) * 2), 'query': {
                'recordType': 'CPLAssetAndMasterByAddedDate', 'filterBy': [
                    {'fieldName': 'direction', 'comparator': 'EQUALS',
                     'fieldValue': {'value': 'ASCENDING', 'type': 'STRING'}},
                    {'fieldName': 'startRank', 'comparator': 'EQUALS',
                     'fieldValue': {'value': offset, 'type': 'INT64'}}]}}
            page = self.api(endpoint, payload).get('records', [])
            page_assets = [r for r in page if r['recordType'] == 'CPLAsset' and not r.get('deleted')]
            for r in page:
                if r['recordType'] == 'CPLMaster' and not r.get('deleted'):
                    masters[r['recordName']] = r
            if not page_assets:
                raise RuntimeError('Incomplete album listing; keeping the previous cache')
            assets.extend(page_assets)
            offset += len(page_assets)
        fields = resolved['share'].get('fields', {})
        title = fields.get('cloudkit.title', {}).get('value', 'Photo Frame')
        return title, assets, masters

    @staticmethod
    def resource(master):
        f = master['fields']
        media_type = f.get('itemType', {}).get('value', '')
        video = f.get('dataClassType', {}).get('value') == 2 or media_type in (
            'public.movie', 'public.video', 'public.mpeg-4', 'com.apple.quicktime-movie',
            'public.avi', 'public.mpeg')
        if video:
            # Prefer Apple's smaller web rendition over the camera original.
            for name in ('resVidMed', 'resVidSmall', 'resVidFull', 'resVideoMed', 'resOriginal'):
                item = f.get(name + 'Res', {}).get('value')
                if item:
                    uti = f.get(name + 'FileType', {}).get('value', 'public.mpeg-4')
                    return item, '.mov' if uti == 'com.apple.quicktime-movie' else '.mp4', 'video', uti
            return None, None, 'video', None
        for name in ('resJPEGFull', 'resJPEGMed', 'resOriginal', 'resJPEGThumb'):
            item = f.get(name + 'Res', {}).get('value')
            uti = f.get(name + 'FileType', {}).get('value', '')
            if item and (uti in ('public.jpeg', 'public.png') or name.startswith('resJPEG')):
                uti = 'public.png' if uti == 'public.png' else 'public.jpeg'
                return item, '.png' if uti == 'public.png' else '.jpg', 'photo', uti
        return None, None, 'photo', None

    def sync(self):
        with self.lock:
            self.status.update(syncing=True, last_attempt=time.time(), error=None)
        try:
            title, assets, masters = self.records()
            manifest = []
            downloaded = 0
            skipped = 0
            cache_size = sum(p.stat().st_size for p in self.photos.iterdir() if p.is_file())
            for asset in assets:
                f = asset['fields']
                master = masters.get(f.get('masterRef', {}).get('value', {}).get('recordName'))
                if master is None:
                    raise RuntimeError('Missing photo metadata; keeping previous cache')
                resource, ext, kind, uti = self.resource(master)
                if not resource:
                    skipped += 1
                    continue
                limit = (200 if kind == 'video' else 40) * 1024 * 1024
                if resource.get('size', 0) > limit:
                    skipped += 1
                    continue
                checksum = resource['fileChecksum']
                filename = hashlib.sha256(checksum.encode()).hexdigest() + ext
                target = self.photos / filename
                if not target.exists():
                    url = resource['downloadURL'].replace('${f}', uti)
                    part = self.photos / (filename + '.part')
                    try:
                        with self.request(url) as response, part.open('wb') as out:
                            total = 0
                            while True:
                                block = response.read(65536)
                                if not block:
                                    break
                                total += len(block)
                                if total > limit:
                                    raise RuntimeError('Media exceeds the per-file cache limit')
                                out.write(block)
                        with part.open('rb') as check:
                            signature = check.read(8)
                        valid_image = signature.startswith(b'\xff\xd8\xff') or signature == b'\x89PNG\r\n\x1a\n'
                        valid_video = signature[4:8] in (b'ftyp', b'moov', b'wide', b'mdat')
                        if not (valid_video if kind == 'video' else valid_image):
                            raise RuntimeError('Download was not a supported image/video container')
                        os.replace(part, target)
                    finally:
                        if part.exists():
                            part.unlink()
                    downloaded += 1
                    cache_size += target.stat().st_size
                manifest.append({'id': asset['recordName'], 'file': filename, 'kind': kind})
                if cache_size > self.config.get('max_cache_bytes', 2 * 1024 ** 3):
                    raise RuntimeError('Photo cache is full; keeping previous slideshow')
            # Publish only a complete sync. A network failure never destroys cached photos.
            manifest = unique_manifest(manifest)
            atomic_json(self.manifest_path, manifest)
            with self.lock:
                self.manifest = manifest
                self.status.update(title=title, count=len(manifest), skipped=skipped,
                                   last_success=time.time(), downloaded=downloaded, error=None,
                                   videos=sum(p.get('kind') == 'video' for p in manifest))
            keep = {p['file'] for p in manifest}
            # Retain removed files for a day so an already-visible slide still loads.
            for p in self.photos.iterdir():
                if p.name not in keep and p.is_file() and time.time() - p.stat().st_mtime > 86400:
                    p.unlink()
            LOG.info('Album synced: %s photos, %s new, %s skipped', len(manifest), downloaded, skipped)
            self.diagnostics.sync(True, len(manifest), downloaded)
        except Exception as error:
            # Do not log signed download URLs / public-access bearer tokens.
            message = str(error) if isinstance(error, RuntimeError) else type(error).__name__
            with self.lock:
                self.status['error'] = message
            LOG.warning('Sync failed (%s); retaining cached photos', message)
            self.diagnostics.sync(False)
        finally:
            with self.lock:
                self.status.update(syncing=False, next_sync=time.time() + self.config.get('sync_seconds', 300))
                atomic_json(self.status_path, self.status)

    def loop(self):
        while self.running:
            self.sync()
            self.wake.wait(self.config.get('sync_seconds', 300))
            self.wake.clear()


def handler(album):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, status, body, content_type):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/health':
                return self.send(200, json.dumps({'build': BUILD, 'ready': True}).encode(), 'application/json')
            if path == '/api/update':
                return self.send(200, json.dumps(album.update_state()).encode(), 'application/json')
            if path == '/api/faces':
                query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                names=query.get('files',[''])[0].split(',')[:6]
                names=[n for n in names if re.fullmatch(r'[0-9a-f]{64}\.(jpg|png)',n)]
                return self.send(200,json.dumps(album.face_state(names)).encode(),'application/json')
            if path == '/api/display':
                return self.send(200, json.dumps(album.display_state()).encode(), 'application/json')
            if path == '/api/photos':
                with album.lock:
                    result = ['/photos/' + p['file'] for p in album.manifest
                              if (album.photos / p['file']).is_file()]
                return self.send(200, json.dumps(result).encode(), 'application/json')
            if path == '/api/status':
                with album.lock:
                    result = dict(album.status)
                    result['client'] = dict(album.client)
                    result['video'] = dict(getattr(album, 'last_video', {}))
                return self.send(200, json.dumps(result, ensure_ascii=False).encode(), 'application/json; charset=utf-8')
            if path == '/api/diagnostics':
                return self.send(200, json.dumps(album.diagnostic_state()).encode(), 'application/json')
            if path in ('/layout.js', '/shuffle.js'):
                return self.send(200, (ROOT / path[1:]).read_bytes(), 'application/javascript; charset=utf-8')
            if path in ('/', '/index.html'):
                return self.send(200, (ROOT / 'index.html').read_bytes(), 'text/html; charset=utf-8')
            if path.startswith('/photos/'):
                name = path[len('/photos/'):]
                if not re.fullmatch(r'[0-9a-f]{64}\.(jpg|png|mp4|mov)', name):
                    return self.send(404, b'Not found', 'text/plain')
                photo = album.photos / name
                if photo.is_file():
                    size = photo.stat().st_size
                    mime = {'.jpg': 'image/jpeg', '.png': 'image/png',
                            '.mp4': 'video/mp4', '.mov': 'video/quicktime'}[photo.suffix]
                    start, end = 0, size - 1
                    requested = self.headers.get('Range')
                    if requested:
                        match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested.strip())
                        try:
                            if not match or not any(match.groups()):
                                raise ValueError()
                            if match[1]:
                                start = int(match[1])
                                if match[2]:
                                    end = min(end, int(match[2]))
                            else:
                                length = int(match[2])
                                if length <= 0:
                                    raise ValueError()
                                start = max(0, size - length)
                            if start > end or start >= size:
                                raise ValueError()
                        except ValueError:
                            self.send_response(416)
                            self.send_header('Content-Range', 'bytes */' + str(size))
                            self.send_header('Content-Length', '0')
                            self.end_headers()
                            return
                    self.send_response(206 if requested else 200)
                    self.send_header('Content-Type', mime)
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Content-Length', str(end - start + 1))
                    self.send_header('Cache-Control', 'private, max-age=86400')
                    if requested:
                        self.send_header('Content-Range', 'bytes %s-%s/%s' % (start, end, size))
                    self.end_headers()
                    try:
                        with photo.open('rb') as source:
                            source.seek(start)
                            remaining = end - start + 1
                            while remaining > 0:
                                block = source.read(min(65536, remaining))
                                if not block:
                                    break
                                self.wfile.write(block)
                                remaining -= len(block)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
            return self.send(404, b'Not found', 'text/plain')

        def do_POST(self):
            origin = self.headers.get('Origin')
            if origin and urllib.parse.urlsplit(origin).hostname not in ('127.0.0.1', 'localhost', '::1'):
                return self.send(403, b'Forbidden', 'text/plain')
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/update':
                try:
                    if self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json':
                        raise ValueError('JSON required')
                    size = int(self.headers.get('Content-Length', 0))
                    if not 1 <= size <= 256:
                        raise ValueError('Invalid action size')
                    command = json.loads(self.rfile.read(size))
                    action = command.get('action')
                    if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'):
                        return self.send(403, b'Forbidden', 'text/plain')
                    build = command.get('build')
                    if action == 'ready' and (not isinstance(build, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}', build)):
                        raise ValueError('Invalid update build')
                    if action not in ('check', 'install', 'ready', 'auto'):
                        raise ValueError('Invalid action')
                    settings = read_json(album.frame_base / 'updater' / 'config.json', {})
                    if not settings.get('enabled'):
                        return self.send(409, b'{"error":"disabled"}', 'application/json')
                    if action == 'auto':
                        album.set_auto_update(command.get('enabled'))
                        return self.send(200, json.dumps(album.update_state()).encode(), 'application/json')
                    folder = album.frame_base / 'updates' / 'commands'
                    folder.mkdir(parents=True, exist_ok=True)
                    if len(list(folder.glob('*.json'))) >= 10:
                        return self.send(429, b'{"error":"busy"}', 'application/json')
                    atomic_json(folder / (uuid.uuid4().hex + '.json'), {'action': action, 'build': build})
                    return self.send(200, b'{"queued":true}', 'application/json')
                except (ValueError, TypeError, AttributeError):
                    return self.send(400, b'{"error":"invalid_action"}', 'application/json')
                except OSError:
                    LOG.exception('Update settings or command could not be saved')
                    return self.send(503, b'{"error":"save_failed"}', 'application/json')
            if path == '/api/display':
                try:
                    size = int(self.headers.get('Content-Length', 0))
                    if not 1 <= size <= 2048:
                        raise ValueError('Invalid settings size')
                    value = validate_night(json.loads(self.rfile.read(size)))
                    with album.lock:
                        atomic_json(album.night_path, value)
                        album.night = value
                    return self.send(200, json.dumps(album.display_state()).encode(), 'application/json')
                except (ValueError, TypeError) as error:
                    return self.send(400, json.dumps({'error': str(error)}).encode(), 'application/json')
            if path == '/api/sync':
                album.wake.set()
                return self.send(200, b'{"queued":true}', 'application/json')
            if path == '/api/diagnostics':
                try:
                    size = int(self.headers.get('Content-Length', 0))
                    if not 1 <= size <= 128 or json.loads(self.rfile.read(size)) != {'action': 'start'}:
                        raise ValueError('Invalid diagnostic action')
                    result = album.diagnostics.start()
                    album.reports.wake.set()
                    return self.send(200, json.dumps(album.diagnostic_state()).encode(), 'application/json')
                except (ValueError, TypeError):
                    return self.send(400, b'{"error":"invalid_action"}', 'application/json')
                except OSError:
                    return self.send(503, b'{"error":"diagnostics_unavailable"}', 'application/json')
            if path == '/api/reports':
                try:
                    size = int(self.headers.get('Content-Length',0))
                    if not 1 <= size <= 1024:raise ValueError('Invalid report settings')
                    value = json.loads(self.rfile.read(size))
                    if not isinstance(value,dict):raise ValueError('Invalid report settings')
                    if value.get('action') == 'test':album.reports.step(test=True)
                    elif value.get('action') == 'save':album.reports.save(value.get('enabled'),value.get('endpoint',''))
                    else:raise ValueError('Invalid report action')
                    return self.send(200,json.dumps(album.diagnostic_state()).encode(),'application/json')
                except (ValueError,TypeError):
                    return self.send(400,b'{"error":"report_settings_invalid"}','application/json')
                except OSError:
                    return self.send(503,b'{"error":"report_unavailable"}','application/json')
            if path == '/api/client':
                try:
                    size = int(self.headers.get('Content-Length', 0))
                    if size < 1 or size > 2048:
                        raise ValueError('Invalid report size')
                    data = json.loads(self.rfile.read(size))
                    if not isinstance(data, dict):
                        raise ValueError('Invalid report')
                    with album.lock:
                        album.client = {k: data.get(k) for k in
                                        ('loaded', 'width', 'height', 'standalone', 'userAgent', 'kind', 'event', 'currentTime', 'duration', 'build', 'night', 'nightClock', 'language', 'recoveries', 'hidden', 'photoCount', 'viewport', 'shuffle', 'remaining', 'seenCount', 'videoBackdrop', 'faceAware', 'facesApplied')}
                        album.client['seen'] = time.time()
                        if data.get('kind') == 'video':
                            album.last_video = dict(album.client)
                    album.diagnostics.record(data)
                    return self.send(200, b'{"ok":true}', 'application/json')
                except (ValueError, TypeError):
                    return self.send(400, b'Invalid report', 'text/plain')
            return self.send(404, b'Not found', 'text/plain')
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(ROOT / 'config.json'))
    parser.add_argument('--sync-once', action='store_true')
    args = parser.parse_args()
    config = read_json(Path(args.config), {})
    parent = os.environ.get('FRAME_SUPERVISOR_PID')
    if parent:
        # Do not leave an orphan occupying the port if the supervisor is killed.
        def watch_parent():
            while os.getppid() == int(parent):
                time.sleep(1)
            os._exit(0)
        threading.Thread(target=watch_parent, daemon=True).start()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    album = Album(config)
    logfile = RotatingFileHandler(str(album.data / 'photoframe.log'), maxBytes=1048576, backupCount=2)
    logfile.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    LOG.addHandler(logfile)
    if args.sync_once:
        album.sync()
        raise SystemExit(1 if album.status.get('error') else 0)
    threading.Thread(target=album.loop, daemon=True).start()
    threading.Thread(target=album.face_loop, daemon=True).start()
    threading.Thread(target=album.auto_update_loop, daemon=True).start()
    threading.Thread(target=album.report_loop, daemon=True).start()
    server = ThreadingHTTPServer(('127.0.0.1', config.get('port', 8080)), handler(album))
    LOG.info('Photo Frame ready on http://127.0.0.1:%s', server.server_port)
    server.serve_forever()


if __name__ == '__main__':
    main()
