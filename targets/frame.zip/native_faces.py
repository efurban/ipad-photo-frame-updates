"""Local Apple Vision face rectangles on an orientation-correct 640px thumbnail.

No photo upload, package install, or full-resolution bitmap allocation.
Loaded only by the isolated face worker, never by the HTTP server.
"""
import ctypes as C

P=C.c_void_p
class Point(C.Structure): _fields_=[('x',C.c_double),('y',C.c_double)]
class Size(C.Structure): _fields_=[('width',C.c_double),('height',C.c_double)]
class Rect(C.Structure): _fields_=[('origin',Point),('size',Size)]

class Detector:
    def __init__(self):
        self.objc=C.CDLL('/usr/lib/libobjc.A.dylib')
        self.foundation=C.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
        self.vision=C.CDLL('/System/Library/Frameworks/Vision.framework/Vision')
        self.io=C.CDLL('/System/Library/Frameworks/ImageIO.framework/ImageIO')
        self.cf=C.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        self.cg=C.CDLL('/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics')
        self.objc.objc_getClass.argtypes=[C.c_char_p];self.objc.objc_getClass.restype=P
        self.objc.sel_registerName.argtypes=[C.c_char_p];self.objc.sel_registerName.restype=P
        self.address=C.cast(self.objc.objc_msgSend,P).value
        self.io.CGImageSourceCreateWithURL.argtypes=[P,P];self.io.CGImageSourceCreateWithURL.restype=P
        self.io.CGImageSourceCreateThumbnailAtIndex.argtypes=[P,C.c_size_t,P];self.io.CGImageSourceCreateThumbnailAtIndex.restype=P
        self.cf.CFRelease.argtypes=[P]
        self.cg.CGImageRelease.argtypes=[P]
    def cls(self,name):
        value=self.objc.objc_getClass(name.encode())
        if not value:raise RuntimeError('Missing Apple framework class: '+name)
        return value
    def msg(self,obj,name,*args,restype=P,types=None):
        fn=C.CFUNCTYPE(restype,P,P,*(types or [P]*len(args)))(self.address)
        return fn(obj,self.objc.sel_registerName(name.encode()),*args)
    def text(self,value):
        return self.msg(self.cls('NSString'),'stringWithUTF8String:',value.encode(),types=[C.c_char_p])
    def detect(self,path):
        pool=self.msg(self.cls('NSAutoreleasePool'),'new')
        source=image=request=handler=None
        try:
            url=self.msg(self.cls('NSURL'),'fileURLWithPath:',self.text(str(path)))
            source=self.io.CGImageSourceCreateWithURL(url,None)
            if not source:raise RuntimeError('Image source unavailable')
            options=self.msg(self.cls('NSMutableDictionary'),'dictionary')
            yes=P.in_dll(self.cf,'kCFBooleanTrue').value
            for key in ('kCGImageSourceCreateThumbnailFromImageAlways','kCGImageSourceCreateThumbnailWithTransform'):
                self.msg(options,'setObject:forKey:',yes,P.in_dll(self.io,key).value,restype=None)
            number=self.msg(self.cls('NSNumber'),'numberWithInt:',640,types=[C.c_int])
            self.msg(options,'setObject:forKey:',number,P.in_dll(self.io,'kCGImageSourceThumbnailMaxPixelSize').value,restype=None)
            image=self.io.CGImageSourceCreateThumbnailAtIndex(source,0,options)
            if not image:raise RuntimeError('Thumbnail unavailable')
            request=self.msg(self.msg(self.cls('VNDetectFaceRectanglesRequest'),'alloc'),'init')
            self.msg(request,'setUsesCPUOnly:',True,types=[C.c_bool],restype=None)
            empty=self.msg(self.cls('NSDictionary'),'dictionary')
            handler=self.msg(self.msg(self.cls('VNImageRequestHandler'),'alloc'),'initWithCGImage:options:',image,empty)
            requests=self.msg(self.cls('NSArray'),'arrayWithObject:',request)
            error=P()
            ok=self.msg(handler,'performRequests:error:',requests,C.byref(error),types=[P,C.POINTER(P)],restype=C.c_bool)
            if not ok:raise RuntimeError('Apple Vision request failed')
            results=self.msg(request,'results');count=self.msg(results,'count',restype=C.c_size_t)
            faces=[]
            for i in range(min(count,50)):
                observation=self.msg(results,'objectAtIndex:',i,types=[C.c_size_t])
                box=self.msg(observation,'boundingBox',restype=Rect)
                confidence=self.msg(observation,'confidence',restype=C.c_float)
                if confidence < .4:continue
                # Vision uses a lower-left origin; CSS uses upper-left.
                left=max(0.,min(1.,box.origin.x));right=max(0.,min(1.,box.origin.x+box.size.width))
                top=max(0.,min(1.,1-box.origin.y-box.size.height));bottom=max(0.,min(1.,1-box.origin.y))
                if right<=left or bottom<=top:continue
                faces.append({'x':round(left,6),'y':round(top,6),
                              'w':round(right-left,6),'h':round(bottom-top,6)})
            return faces
        finally:
            if handler:self.msg(handler,'release',restype=None)
            if request:self.msg(request,'release',restype=None)
            if image:self.cg.CGImageRelease(image)
            if source:self.cf.CFRelease(source)
            self.msg(pool,'drain',restype=None)

if __name__=='__main__':
    import sys,json,time,resource,os
    try:os.nice(10)
    except OSError:pass
    detector=Detector();start=time.monotonic();faces=detector.detect(sys.argv[1])
    print(json.dumps({'faces':faces,'seconds':round(time.monotonic()-start,3),'peak_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
