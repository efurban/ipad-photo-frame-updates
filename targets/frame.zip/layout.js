/* Small, dependency-free fixed-canvas photo layout. ES5 for iOS 12. */
(function (root) {
  'use strict';
  function layouts(ratios, box) {
    if (ratios.length === 1) return [[box]];
    var results = [];
    for (var cut = 1; cut < ratios.length; cut++) {
      for (var axis = 0; axis < 2; axis++) {
        for (var step = 3; step <= 7; step++) {
          var t = step / 10;
          var a = {x:box.x,y:box.y,w:box.w,h:box.h};
          var b = {x:box.x,y:box.y,w:box.w,h:box.h};
          if (axis === 0) { a.w *= t; b.x += a.w; b.w *= 1-t; }
          else { a.h *= t; b.y += a.h; b.h *= 1-t; }
          var left = layouts(ratios.slice(0,cut),a), right = layouts(ratios.slice(cut),b);
          for (var i=0;i<left.length;i++) for(var j=0;j<right.length;j++) results.push(left[i].concat(right[j]));
        }
      }
    }
    return results;
  }
  function crop(imageRatio,cellRatio,faces) {
    var vw=Math.min(1,cellRatio/imageRatio), vh=Math.min(1,imageRatio/cellRatio);
    if(!faces || !faces.length)return {fit:'cover',x:50,y:50};
    var minX=1,minY=1,maxX=0,maxY=0;
    faces.forEach(function(f){
      minX=Math.min(minX,Math.max(0,f.x-f.w*.25));maxX=Math.max(maxX,Math.min(1,f.x+f.w*1.25));
      minY=Math.min(minY,Math.max(0,f.y-f.h*.4));maxY=Math.max(maxY,Math.min(1,f.y+f.h*1.2));
    });
    if(maxX-minX>vw+.000001 || maxY-minY>vh+.000001)return {fit:'contain',x:50,y:50};
    function axis(min,max,visible){
      if(visible>=.999999)return 50;
      var low=Math.max(0,max-visible),high=Math.min(1-visible,min);
      var origin=Math.max(low,Math.min(high,(min+max-visible)/2));
      return Math.max(0,Math.min(100,origin/(1-visible)*100));
    }
    return {fit:'cover',x:axis(minX,maxX,vw),y:axis(minY,maxY,vh)};
  }
  function choose(ratios, screenRatio, faces) {
    var best = null;
    for(var count=1;count<=Math.min(3,ratios.length);count++) {
      var options = layouts(ratios.slice(0,count),{x:0,y:0,w:1,h:1});
      options.forEach(function(boxes) {
        var lossSum=0,worst=0,valid=true,facePenalty=0;
        boxes.forEach(function(b,i) {
          if(b.w*b.h < 0.219 || b.w < 0.269 || b.h < 0.269) valid=false;
          var r=b.w*screenRatio/b.h;
          var loss=1-Math.min(r/ratios[i],ratios[i]/r);
          lossSum+=b.w*b.h*loss; worst=Math.max(worst,loss);
          if(faces && faces[i] && faces[i].length && crop(ratios[i],r,faces[i]).fit==='contain')facePenalty+=.6*b.w*b.h;
        });
        var score=lossSum+worst*0.15+(count-1)*0.075+facePenalty;
        if(valid && (!best || score<best.score-0.000001)) best={count:count,boxes:boxes,score:score};
      });
    }
    return best;
  }
  root.FrameLayout = {choose:choose,crop:crop};
})(typeof window === 'undefined' ? module.exports : window);
