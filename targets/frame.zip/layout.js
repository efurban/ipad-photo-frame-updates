/* Small, dependency-free fixed-canvas photo layout. ES5 for iOS 12. */
(function (root) {
  'use strict';
  function layouts(ratios, box) {
    if (ratios.length === 1) return [[box]];
    var results = [];
    for (var cut = 1; cut < ratios.length; cut++) {
      for (var axis = 0; axis < 2; axis++) {
        for (var step = 3; step <= 7; step++) {
          var t = step / 10;
          var a = {x:box.x,y:box.y,w:box.w,h:box.h};
          var b = {x:box.x,y:box.y,w:box.w,h:box.h};
          if (axis === 0) { a.w *= t; b.x += a.w; b.w *= 1-t; }
          else { a.h *= t; b.y += a.h; b.h *= 1-t; }
          var left = layouts(ratios.slice(0,cut),a), right = layouts(ratios.slice(cut),b);
          for (var i=0;i<left.length;i++) for(var j=0;j<right.length;j++) results.push(left[i].concat(right[j]));
        }
      }
    }
    return results;
  }
  function crop(imageRatio,cellRatio,faces) {
    var vw=Math.min(1,cellRatio/imageRatio), vh=Math.min(1,imageRatio/cellRatio);
    if(!faces || !faces.length)return {fit:'cover',x:50,y:50};
    var minX=1,minY=1,maxX=0,maxY=0;
    faces.forEach(function(f){
      minX=Math.min(minX,Math.max(0,f.x-f.w*.25));maxX=Math.max(maxX,Math.min(1,f.x+f.w*1.25));
      minY=Math.min(minY,Math.max(0,f.y-f.h*.4));maxY=Math.max(maxY,Math.min(1,f.y+f.h*1.2));
    });
    if(maxX-minX>vw+.000001 || maxY-minY>vh+.000001)return {fit:'contain',x:50,y:50};
    function axis(min,max,visible){
      if(visible>=.999999)return 50;
      var low=Math.max(0,max-visible),high=Math.min(1-visible,min);
      var origin=Math.max(low,Math.min(high,(min+max-visible)/2));
      return Math.max(0,Math.min(100,origin/(1-visible)*100));
    }
    return {fit:'cover',x:axis(minX,maxX,vw),y:axis(minY,maxY,vh)};
  }
  function choose(ratios, screenRatio, faces) {
    var best = null;
    for(var count=1;count<=Math.min(3,ratios.length);count++) {
      var options = layouts(ratios.slice(0,count),{x:0,y:0,w:1,h:1});
      options.forEach(function(boxes) {
        var lossSum=0,worst=0,valid=true,facePenalty=0;
        boxes.forEach(function(b,i) {
          if(b.w*b.h < 0.219 || b.w < 0.269 || b.h < 0.269) valid=false;
          var r=b.w*screenRatio/b.h;
          var loss=1-Math.min(r/ratios[i],ratios[i]/r);
          lossSum+=b.w*b.h*loss; worst=Math.max(worst,loss);
          if(faces && faces[i] && faces[i].length && crop(ratios[i],r,faces[i]).fit==='contain')facePenalty+=.6*b.w*b.h;
        });
        var score=lossSum+worst*0.15+(count-1)*0.075+facePenalty;
        if(valid && (!best || score<best.score-0.000001)) best={count:count,boxes:boxes,score:score};
      });
    }
    return best;
  }
  root.FrameLayout = {choose:choose,crop:crop};
})(typeof window === 'undefined' ? module.exports : window);

/* BEGIN THREE-PAGE ENGINE */
/* Three recycled pages. ES5/Touch Events for iOS 12. */
(function (root) {
  'use strict';
  function clamp(n, low, high) { return Math.max(low, Math.min(high, n)); }
  function now() { return root.performance && root.performance.now ? root.performance.now() : Date.now(); }
  function Pager(element, options) {
    this.root=element;this.options=options;this.index=options.start || 0;
    this.width=element.clientWidth || root.innerWidth;this.height=element.clientHeight || root.innerHeight;
    this.x=-this.width;this.mode='idle';this.gesture=null;this.animation=null;this.frame=0;this.job=null;this.deferred=[];
    this.zoom=null;this.mouse=false;this.destroyed=false;this.revision=0;
    this.stats={dragFrames:0,maxFrameGap:0,lastResponseMs:null,preparationsDuringDrag:0,mounted:3};
    this.track=document.createElement('div');this.track.className='pager-track';element.appendChild(this.track);
    this.slots=[];
    for(var i=0;i<3;i++) {
      var el=document.createElement('section');el.className='pager-page';el.setAttribute('aria-hidden','true');
      this.track.appendChild(el);this.slots.push({el:el,index:null,view:null,ready:false,revision:0});
    }
    this._position();this._sync();this._bind();
  }
  Pager.prototype._position=function () {
    for(var i=0;i<3;i++)this.slots[i].el.style.left=(i*100)+'%';
    this.track.style.webkitTransform=this.track.style.transform='translate3d('+this.x+'px,0,0)';
  };
  Pager.prototype._paint=function () {
    this.track.style.webkitTransform=this.track.style.transform='translate3d('+this.x+'px,0,0)';
    if(this.zoom) {
      var z=this.zoom;
      z.image.style.webkitTransform=z.image.style.transform=z.scale>1 ? 'translate3d('+z.x+'px,'+z.y+'px,0) scale('+z.scale+')' : '';
    }
  };
  Pager.prototype._mode=function (value) {
    this.mode=value;if(this.options.busy)this.options.busy(value!=='idle');
  };
  Pager.prototype._changed=function () {
    if(this.options.change)this.options.change(this.index,this.slots[1].ready,this.stats);
  };
  Pager.prototype._dispose=function (slot) {
    if(this.job && this.job.slot===slot){if(this.job.cancel)this.job.cancel();this.job=null;}
    slot.revision++;if(slot.view && slot.view.dispose)slot.view.dispose();
    while(slot.el.firstChild)slot.el.removeChild(slot.el.firstChild);
    slot.view=null;slot.ready=false;slot.failed=false;
  };
  Pager.prototype._sync=function () {
    for(var i=0;i<3;i++) {
      var slot=this.slots[i],index=this.index+i-1;
      if(slot.index!==index){this._dispose(slot);slot.index=index;}
      slot.el.setAttribute('aria-hidden',i===1?'false':'true');
    }
    this._changed();this._pump();
  };
  Pager.prototype._pump=function () {
    if(this.destroyed || this.mode!=='idle' || this.job || this.options.canPrepare && !this.options.canPrepare())return;
    var self=this,priorities=[1,0,2],slot=null;
    for(var i=0;i<3;i++) {
      var candidate=this.slots[priorities[i]];
      if(candidate.index>=0 && candidate.index<this.options.count() && !candidate.ready && !candidate.failed){slot=candidate;break;}
    }
    if(!slot)return;
    var job={slot:slot,revision:slot.revision,index:slot.index,cancel:null,result:null};this.job=job;
    function loaded(error,view) {
      if(job.returned){if(view && view.dispose)view.dispose();return;}job.returned=true;
      if(self.destroyed || slot.revision!==job.revision || slot.index!==job.index) {
        if(view && view.dispose)view.dispose();if(self.job===job)self.job=null;self._pump();return;
      }
      job.result={error:error,view:view};
      self.defer(function () {
        if(self.job!==job || slot.revision!==job.revision || self.destroyed){if(view && view.dispose)view.dispose();return;}
        self.job=null;
        if(error && error.unavailable){slot.failed=true;slot.ready=false;}
        else if(error){
          var fallback=document.createElement('div');fallback.className='pager-error';fallback.textContent='Photo unavailable';
          slot.view={node:fallback};slot.el.appendChild(fallback);slot.ready=true;slot.failed=true;
          if(self.options.error)self.options.error(error);
        }
        else {slot.view=view;slot.el.appendChild(view.node);slot.ready=true;slot.failed=false;}
        if(slot===self.slots[1] && slot.ready)self._activate();
        self._changed();self._pump();
      });
    }
    job.cancel=this.options.prepare(job.index,loaded) || null;
  };
  Pager.prototype.defer=function (fn) {
    if(this.destroyed)return;
    if(this.mode==='idle')fn();else this.deferred.push(fn);
  };
  Pager.prototype._idle=function () {
    this._mode('idle');var tasks=this.deferred;this.deferred=[];
    for(var i=0;i<tasks.length;i++)tasks[i]();
    this._pump();this._activate();this._changed();
  };
  Pager.prototype._activate=function () {
    if(this.mode==='idle' && this.slots[1].view && this.slots[1].view.activate)this.slots[1].view.activate();
  };
  Pager.prototype._pause=function () {
    if(this.slots[1].view && this.slots[1].view.pause)this.slots[1].view.pause();
  };
  Pager.prototype._stop=function () {
    if(this.frame)root.cancelAnimationFrame(this.frame);
    this.frame=0;this.animation=null;
  };
  Pager.prototype._neighbor=function (direction) {return direction && this.slots[direction<0?0:2].ready;};
  Pager.prototype._limit=function (position) {
    return clamp(position,this._neighbor(1)?-2*this.width:-this.width,this._neighbor(-1)?0:-this.width);
  };
  Pager.prototype._commit=function (direction) {
    if(!direction || !this._neighbor(direction))return;
    this._resetZoom();var previous=this.slots[1];
    if(previous.view && previous.view.deactivate)previous.view.deactivate();
    var recycled=direction>0?this.slots.shift():this.slots.pop();
    if(direction>0)this.slots.push(recycled);else this.slots.unshift(recycled);
    this.index+=direction;this.x=-this.width;this._position();this._sync();
  };
  Pager.prototype._settle=function (direction,velocity,finished) {
    if(!this._neighbor(direction))direction=0;
    this._stop();this._mode('settle');var self=this,from=this.x,to=-this.width-direction*this.width;
    var distance=Math.abs(to-from),duration=clamp(distance/(Math.max(0.6,Math.abs(velocity || 0))+2),130,290);
    var animation={from:from,to:to,start:now(),duration:duration,direction:direction};this.animation=animation;
    function tick(time) {
      if(self.animation!==animation || self.destroyed)return;
      var t=clamp((time-animation.start)/duration,0,1),eased=1-Math.pow(1-t,3);
      self.x=from+(to-from)*eased;self._paint();
      if(t<1)self.frame=root.requestAnimationFrame(tick);
      else {self.frame=0;self.animation=null;self._commit(direction);self.x=-self.width;self._paint();self._idle();if(finished)finished();}
    }
    if(distance<0.5){this.animation=null;this.x=to;this._commit(direction);this.x=-this.width;this._paint();this._idle();if(finished)finished();}
    else this.frame=root.requestAnimationFrame(tick);
  };
  Pager.prototype.go=function (direction) {
    if(this.mode!=='idle' || !this.slots[1].ready)return false;
    if(!this._neighbor(direction))return false;
    this._pause();this._settle(direction,1);return true;
  };
  Pager.prototype._queuePaint=function () {
    if(this.frame)return;var self=this;
    this.frame=root.requestAnimationFrame(function (time) {
      self.frame=0;if(self.destroyed)return;
      if(self.mode==='drag' && self.gesture) {
        var g=self.gesture;
        if(g.firstMove!==null && !g.responded){self.stats.lastResponseMs=now()-g.firstMove;g.responded=true;}
        if(g.lastFrame)self.stats.maxFrameGap=Math.max(self.stats.maxFrameGap,time-g.lastFrame);
        g.lastFrame=time;self.stats.dragFrames++;
      }
      self._paint();
    });
  };
  Pager.prototype._focus=function (target) {
    var slot=this.slots[1];if(!slot.view || !slot.view.focus)return null;
    return slot.view.focus(target);
  };
  Pager.prototype._resetZoom=function () {
    if(this.zoom){this.zoom.image.style.webkitTransform=this.zoom.image.style.transform='';this.zoom=null;}
    if(this.slots[1].view && this.slots[1].view.unfocus)this.slots[1].view.unfocus();
  };
  Pager.prototype._clampZoom=function () {
    var z=this.zoom;if(!z)return;
    var ratio=z.image.naturalWidth/z.image.naturalHeight,w=Math.min(this.width,this.height*ratio),h=Math.min(this.height,this.width/ratio);
    var maxX=Math.max(0,(w*z.scale-this.width)/2),maxY=Math.max(0,(h*z.scale-this.height)/2);
    z.x=clamp(z.x,-maxX,maxX);z.y=clamp(z.y,-maxY,maxY);
  };
  Pager.prototype._pinch=function (touches,target) {
    var selected=this._focus(target);if(!selected)return false;
    if(!this.zoom || this.zoom.image!==selected.image)this.zoom={image:selected.image,scale:1,x:0,y:0};
    var a=touches[0],b=touches[1],z=this.zoom,rect=this.root.getBoundingClientRect();
    this.gesture={pinch:true,distance:Math.max(1,Math.sqrt(Math.pow(a.clientX-b.clientX,2)+Math.pow(a.clientY-b.clientY,2))),
      scale:z.scale,x:z.x,y:z.y,midX:(a.clientX+b.clientX)/2-rect.left-this.width/2,midY:(a.clientY+b.clientY)/2-rect.top-this.height/2,
      rootX:rect.left,rootY:rect.top,hadPinch:true};
    this._mode('pinch');return true;
  };
  Pager.prototype._start=function (touches,target) {
    if(!touches.length || !this.slots[1].ready || this.options.canStart && !this.options.canStart())return;
    this._pause();
    if(touches.length>=2) {
      // Resolve an interrupted page slide before a new two-finger gesture.
      if(this.mode==='settle' || this.mode==='drag') {
        var delta=this.x+this.width,direction=Math.abs(delta)>this.width/2?(delta<0?1:-1):0;
        this._stop();this._commit(direction);this.x=-this.width;this._paint();
      }
      if(!this._pinch(touches,target)){this.gesture={ignore:true};this._mode('pinch');}
      return;
    }
    var p=touches[0],time=now();this._stop();
    if(this.zoom && this.zoom.scale>1.01) {
      this.gesture={pan:true,startX:p.clientX,startY:p.clientY,x:this.zoom.x,y:this.zoom.y,start:time,moved:false,target:target};this._mode('pan');return;
    }
    // x is retained when a running settle animation is picked up again.
    this.gesture={startX:p.clientX,startY:p.clientY,base:this.x,lastX:p.clientX,lastTime:time,velocity:0,start:time,target:target,
      horizontal:false,vertical:false,moved:false,firstMove:null,lastFrame:0,responded:false};
    this._mode('drag');
  };
  Pager.prototype._move=function (touches) {
    var g=this.gesture;if(!g || g.ignore || !touches.length)return;
    var p=touches[0];
    if(g.pinch && touches.length>=2) {
      var b=touches[1],distance=Math.sqrt(Math.pow(p.clientX-b.clientX,2)+Math.pow(p.clientY-b.clientY,2)),z=this.zoom;
      z.scale=clamp(g.scale*distance/g.distance,1,4);var factor=z.scale/g.scale;
      z.x=(p.clientX+b.clientX)/2-g.rootX-this.width/2-(g.midX-g.x)*factor;
      z.y=(p.clientY+b.clientY)/2-g.rootY-this.height/2-(g.midY-g.y)*factor;
      this._clampZoom();this._queuePaint();return;
    }
    var dx=p.clientX-g.startX,dy=p.clientY-g.startY;
    if(g.pan){if(Math.abs(dx)>5 || Math.abs(dy)>5)g.moved=true;this.zoom.x=g.x+dx;this.zoom.y=g.y+dy;this._clampZoom();this._queuePaint();return;}
    if(!g.horizontal && !g.vertical) {
      if(Math.max(Math.abs(dx),Math.abs(dy))<6)return;
      if(Math.abs(dy)>Math.abs(dx)){g.vertical=true;return;}g.horizontal=true;g.moved=true;g.firstMove=now();
    }
    if(g.vertical)return;
    var time=now(),elapsed=time-g.lastTime;
    if(elapsed>0)g.velocity=clamp((p.clientX-g.lastX)/elapsed,-3,3);
    g.lastX=p.clientX;g.lastTime=time;this.x=this._limit(g.base+dx);this._queuePaint();
  };
  Pager.prototype._end=function (touches,changed,cancelled) {
    var g=this.gesture;if(!g)return;
    if(!cancelled && !g.pan && !g.pinch && !g.ignore && changed.length && changed[0].clientX!==g.lastX)this._move([changed[0]]);
    if((g.pinch || g.pan || g.ignore) && touches.length) {
      if(touches.length===1 && this.zoom){var p=touches[0];this.gesture={pan:true,startX:p.clientX,startY:p.clientY,x:this.zoom.x,y:this.zoom.y,start:now(),moved:true,hadPinch:true};this._mode('pan');}
      return;
    }
    this.gesture=null;this._stop();this._paint();
    if(g.pinch || g.pan || g.ignore) {
      this._idle();
      if(!cancelled && g.pan && !g.moved && !g.hadPinch && now()-g.start<300 && this.options.tap)this.options.tap(g.target,g.startX);
      return;
    }
    var delta=this.x+this.width,velocity=now()-g.lastTime>90?0:g.velocity;
    var direction=0;
    if(!cancelled) {
      if(g.horizontal && Math.abs(delta)>12 && Math.abs(velocity)>0.45)direction=delta*velocity>0?(delta<0?1:-1):0;
      else if(Math.abs(delta)>this.width*0.18)direction=delta<0?1:-1;
    }
    var tap=!cancelled && !g.moved && now()-g.start<300 && Math.abs(delta)<2;
    var raw=g.lastX-g.startX,missing=!cancelled && g.horizontal && Math.abs(raw)>50 && !this._neighbor(raw<0?1:-1),self=this;
    this._settle(direction,velocity,missing && this.options.missing ? function(){self.options.missing(raw<0?1:-1);} : null);
    if(tap && this.options.tap)this.options.tap(g.target,g.startX);
  };
  Pager.prototype.resize=function () {
    // Rotation invalidates the old geometry; keep the current page rather
    // than treating a partial drag as a request to navigate.
    this._stop();this.gesture=null;
    this.width=this.root.clientWidth || root.innerWidth;this.height=this.root.clientHeight || root.innerHeight;
    this.x=-this.width;this._clampZoom();this._position();
    for(var i=0;i<3;i++)if(this.slots[i].view && this.slots[i].view.resize)this.slots[i].view.resize(this.width,this.height);
    this._paint();this._idle();
  };
  Pager.prototype._bind=function () {
    var self=this,delegated=false;this.handlers={
      start:function(e){
        self.lastTouch=now();
        if(self.options.delegate && (delegated || self.options.delegate(e))) {
          if(!delegated){self._stop();self.gesture=null;self.x=-self.width;self._paint();self._idle();delegated=true;}return;
        }
        if(self.options.exclusive)e.stopPropagation();if(e.cancelable)e.preventDefault();self._start(e.touches || [],e.target);
      },
      move:function(e){if(delegated)return;if(self.options.exclusive)e.stopPropagation();if(e.cancelable)e.preventDefault();self._move(e.touches || []);},
      end:function(e){self.lastTouch=now();if(delegated){if(!e.touches || !e.touches.length)delegated=false;return;}if(self.options.exclusive)e.stopPropagation();self._end(e.touches || [],e.changedTouches || [],false);if(self.options.touchEnd)self.options.touchEnd();},
      cancel:function(e){self.lastTouch=now();if(delegated){delegated=false;return;}if(self.options.exclusive)e.stopPropagation();self._end([],e.changedTouches || [],true);if(self.options.touchEnd)self.options.touchEnd();},
      down:function(e){if(e.button!==0 || self.lastTouch && now()-self.lastTouch<700)return;e.preventDefault();self.mouse=true;self._start([e],e.target);},
      mousemove:function(e){if(self.mouse)self._move([e]);},up:function(e){if(self.mouse){self.mouse=false;self._end([], [e],false);if(self.options.touchEnd)self.options.touchEnd();}},
      resize:function(){self.resize();},gesture:function(e){if(e.cancelable)e.preventDefault();}
    };
    var h=this.handlers;
    this.root.addEventListener('touchstart',h.start,{passive:false});this.root.addEventListener('touchmove',h.move,{passive:false});
    this.root.addEventListener('touchend',h.end);this.root.addEventListener('touchcancel',h.cancel);
    this.root.addEventListener('gesturestart',h.gesture,{passive:false});
    this.root.addEventListener('mousedown',h.down);document.addEventListener('mousemove',h.mousemove);document.addEventListener('mouseup',h.up);
    root.addEventListener('resize',h.resize);
  };
  Pager.prototype.destroy=function () {
    this.destroyed=true;this._stop();this.deferred=[];if(this.job && this.job.cancel)this.job.cancel();this.job=null;
    for(var i=0;i<3;i++)this._dispose(this.slots[i]);
    var h=this.handlers;
    this.root.removeEventListener('touchstart',h.start);this.root.removeEventListener('touchmove',h.move);
    this.root.removeEventListener('touchend',h.end);this.root.removeEventListener('touchcancel',h.cancel);this.root.removeEventListener('gesturestart',h.gesture);
    this.root.removeEventListener('mousedown',h.down);document.removeEventListener('mousemove',h.mousemove);document.removeEventListener('mouseup',h.up);root.removeEventListener('resize',h.resize);
    if(this.track.parentNode)this.track.parentNode.removeChild(this.track);
  };
  root.FramePager=Pager;
})(typeof window === 'undefined' ? module.exports : window);

/* END THREE-PAGE ENGINE */
